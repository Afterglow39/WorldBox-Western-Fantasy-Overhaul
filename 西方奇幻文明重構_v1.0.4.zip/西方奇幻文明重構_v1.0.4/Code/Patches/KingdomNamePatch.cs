﻿using System.Collections.Generic;
using Chinese_Name.utils;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General.Event.Handlers;
using NeoModLoader.General.Event.Listeners;

namespace Chinese_Name;

public class KingdomNamePatch : IPatch
{
    public void Initialize()
    {
        //KingdomSetupListener.RegisterHandler(new RenameKingdom());
        new Harmony(nameof(set_kingdom_name)).Patch(AccessTools.Method(typeof(Kingdom), nameof(Kingdom.newCivKingdom)),
            postfix: new HarmonyMethod(AccessTools.Method(GetType(), nameof(set_kingdom_name))));
        new Harmony(nameof(set_kingdom_motto)).Patch(AccessTools.Method(typeof(Kingdom), nameof(Kingdom.getMotto)),
            prefix: new HarmonyMethod(AccessTools.Method(GetType(), nameof(set_kingdom_motto))));
    }
    [Hotfixable]
private static void set_kingdom_name(Kingdom __instance, Actor pActor)
{
    string race_id = pActor.asset.id;
        string template_id;
        string core_race = CoreRaceFramework.FromActor(pActor);
        if (core_race != null) template_id = CoreRaceFramework.GeneratorId(core_race, "kingdom");
        else if (V20NameHelper.IsBuffolon(pActor)) template_id = "civ_buffalo_kingdom";
        else if (V20NameHelper.IsArmaldar(pActor)) template_id = "civ_armadillo_kingdom";
        else if (V20NameHelper.IsPunkcorn(pActor)) template_id = "civ_unicorn_kingdom";
        else if (V20NameHelper.IsBaakin(pActor)) template_id = "civ_sheep_kingdom";
        else if (V20NameHelper.IsMootaur(pActor)) template_id = "civ_cow_kingdom";
        else if (V20NameHelper.IsSlypaw(pActor)) template_id = "civ_fox_kingdom";
        else if (V20NameHelper.IsPecklord(pActor)) template_id = "civ_chicken_kingdom";
        else if (V20NameHelper.IsBarkfolk(pActor)) template_id = "civ_dog_kingdom";
        else if (V20NameHelper.IsAcidGentleman(pActor)) template_id = "civ_acid_gentleman_kingdom";
        else if (V20NameHelper.IsGarlicMan(pActor)) template_id = "civ_garlic_man_kingdom";
        else if (V20NameHelper.IsMiscCivilizationSource(pActor)) template_id = "civ_misc_kingdom";
        else if (V20NameHelper.IsLemonMan(pActor)) template_id = "civ_lemon_man_kingdom";
        else if (V20NameHelper.IsPlagueDoctor(pActor)) template_id = "civ_plague_doctor_kingdom";
        else if (V20NameHelper.IsDemon(pActor)) template_id = "civ_demon_kingdom";
        else if (V20NameHelper.IsFairy(pActor)) template_id = "civ_fairy_kingdom";
        else if (V20NameHelper.IsEvilMage(pActor)) template_id = "civ_evil_mage_kingdom";
        else if (V20NameHelper.IsAlien(pActor)) template_id = "civ_alien_kingdom";
        else if (V20NameHelper.IsWhiteMage(pActor)) template_id = "civ_white_mage_kingdom";
        else if (V20NameHelper.IsColdOne(pActor)) template_id = "civ_cold_one_kingdom";
        else if (V20NameHelper.IsAngle(pActor)) template_id = "civ_angle_kingdom";
        else if (V20NameHelper.IsSkeleton(pActor)) template_id = "civ_skeleton_kingdom";
        else if (V20NameHelper.IsSnowman(pActor)) template_id = "civ_snowman_kingdom";
        else if (V20NameHelper.IsDruid(pActor)) template_id = "civ_druid_kingdom";
        else if (V20NameHelper.IsGhost(pActor)) template_id = "civ_ghost_kingdom";
        else if (V20NameHelper.IsBandit(pActor)) template_id = "civ_bandit_kingdom";
        else if (V20NameHelper.IsJumpySkull(pActor)) template_id = "civ_jumpy_skull_kingdom";
        else if (V20NameHelper.IsFireSkull(pActor)) template_id = "civ_fire_skull_kingdom";
        else if (V20NameHelper.IsGreg(pActor)) template_id = "civ_greg_kingdom";
        else if (V20NameHelper.IsNecromancer(pActor)) template_id = "civ_necromancer_kingdom";
        else if (V20NameHelper.IsLulclaw(pActor)) template_id = "civ_hyena_kingdom";
        else if (V20NameHelper.IsNibling(pActor)) template_id = "civ_rat_kingdom";
        else if (V20NameHelper.IsCharmaca(pActor)) template_id = "civ_alpaca_kingdom";
        else if (V20NameHelper.IsHerdor(pActor)) template_id = "civ_goat_kingdom";
        else if (V20NameHelper.IsRibbit(pActor)) template_id = "civ_frog_kingdom";
        else if (V20NameHelper.IsGnapkin(pActor)) template_id = "civ_piranha_kingdom";
        else if (V20NameHelper.IsReptiloid(pActor)) template_id = "civ_crocodile_kingdom";
        else if (V20NameHelper.IsMeowmorph(pActor)) template_id = "civ_cat_kingdom";
        else if (V20NameHelper.IsDunglord(pActor)) template_id = "civ_beetle_kingdom";
        else if (V20NameHelper.IsArmococ(pActor)) template_id = "civ_armococ_kingdom";
        else if (V20NameHelper.IsGrranth(pActor)) template_id = "civ_grranth_kingdom";
        else if (V20NameHelper.IsCandyManCivilizationSource(pActor)) template_id = "civ_candy_kingdom";
        else if (V20NameHelper.IsCrab(pActor)) template_id = "civ_crab_kingdom";
        else if (V20NameHelper.IsTurtok(pActor)) template_id = "civ_turtle_kingdom";
        else if (V20NameHelper.IsNavySeal(pActor)) template_id = "civ_seal_kingdom";
        else if (V20NameHelper.IsMonkey(pActor)) template_id = "civ_monkey_kingdom";
        else if (V20NameHelper.IsHopper(pActor)) template_id = "civ_hopper_kingdom";
        else if (V20NameHelper.IsScorp(pActor)) template_id = "civ_scorpion_kingdom";
        else if (V20NameHelper.IsCoolbeak(pActor)) template_id = "civ_coolbeak_kingdom";
        else if (V20NameHelper.IsLiliarCivilizationSource(pActor)) template_id = "civ_liliar_kingdom";
        else if (V20NameHelper.IsWolf(pActor)) template_id = "civ_wolf_kingdom";
        else if (V20NameHelper.IsSnake(pActor)) template_id = "civ_snake_kingdom";
        else if (V20NameHelper.IsCrystalCivilizationSource(pActor)) template_id = "civ_crystal_kingdom";
        else if (V20NameHelper.IsCapybara(pActor)) template_id = "civ_capybara_kingdom";
        else template_id = $"{race_id}_kingdom";
        var generator = CN_NameGeneratorLibrary.Instance.get(template_id);
        if (generator == null) return;

        var para = new Dictionary<string, string>();

        ParameterGetters.GetKingdomParameterGetter(generator.parameter_getter)(__instance, para);

        __instance.data.name = generator.GenerateName(para);
    }
    private static bool set_kingdom_motto(Kingdom __instance)
    {
        if (!string.IsNullOrWhiteSpace(__instance.data.motto)) return true;
        string race_id = __instance.data.original_actor_asset;
        string template_id;
        string core_race = CoreRaceFramework.FromKingdom(__instance);
        if (core_race != null) template_id = CoreRaceFramework.GeneratorId(core_race, "kingdom_motto");
        else if (V20NameHelper.IsBuffolon(__instance)) template_id = "civ_buffalo_kingdom_motto";
        else if (V20NameHelper.IsArmaldar(__instance)) template_id = "civ_armadillo_kingdom_motto";
        else if (V20NameHelper.IsPunkcorn(__instance)) template_id = "civ_unicorn_kingdom_motto";
        else if (V20NameHelper.IsBaakin(__instance)) template_id = "civ_sheep_kingdom_motto";
        else if (V20NameHelper.IsMootaur(__instance)) template_id = "civ_cow_kingdom_motto";
        else if (V20NameHelper.IsSlypaw(__instance)) template_id = "civ_fox_kingdom_motto";
        else if (V20NameHelper.IsPecklord(__instance)) template_id = "civ_chicken_kingdom_motto";
        else if (V20NameHelper.IsBarkfolk(__instance)) template_id = "civ_dog_kingdom_motto";
        else if (V20NameHelper.IsAcidGentleman(__instance)) template_id = "civ_acid_gentleman_kingdom_motto";
        else if (V20NameHelper.IsGarlicMan(__instance)) template_id = "civ_garlic_man_kingdom_motto";
        else if (V20NameHelper.IsMiscCivilizationSource(__instance)) template_id = "civ_misc_kingdom_motto";
        else if (V20NameHelper.IsLemonMan(__instance)) template_id = "civ_lemon_man_kingdom_motto";
        else if (V20NameHelper.IsPlagueDoctor(__instance)) template_id = "civ_plague_doctor_kingdom_motto";
        else if (V20NameHelper.IsDemon(__instance)) template_id = "civ_demon_kingdom_motto";
        else if (V20NameHelper.IsFairy(__instance)) template_id = "civ_fairy_kingdom_motto";
        else if (V20NameHelper.IsEvilMage(__instance)) template_id = "civ_evil_mage_kingdom_motto";
        else if (V20NameHelper.IsAlien(__instance)) template_id = "civ_alien_kingdom_motto";
        else if (V20NameHelper.IsWhiteMage(__instance)) template_id = "civ_white_mage_kingdom_motto";
        else if (V20NameHelper.IsColdOne(__instance)) template_id = "civ_cold_one_kingdom_motto";
        else if (V20NameHelper.IsAngle(__instance)) template_id = "civ_angle_kingdom_motto";
        else if (V20NameHelper.IsSkeleton(__instance)) template_id = "civ_skeleton_kingdom_motto";
        else if (V20NameHelper.IsSnowman(__instance)) template_id = "civ_snowman_kingdom_motto";
        else if (V20NameHelper.IsDruid(__instance)) template_id = "civ_druid_kingdom_motto";
        else if (V20NameHelper.IsGhost(__instance)) template_id = "civ_ghost_kingdom_motto";
        else if (V20NameHelper.IsBandit(__instance)) template_id = "civ_bandit_kingdom_motto";
        else if (V20NameHelper.IsJumpySkull(__instance)) template_id = "civ_jumpy_skull_kingdom_motto";
        else if (V20NameHelper.IsFireSkull(__instance)) template_id = "civ_fire_skull_kingdom_motto";
        else if (V20NameHelper.IsGreg(__instance)) template_id = "civ_greg_kingdom_motto";
        else if (V20NameHelper.IsNecromancer(__instance)) template_id = "civ_necromancer_kingdom_motto";
        else if (V20NameHelper.IsLulclaw(__instance)) template_id = "civ_hyena_kingdom_motto";
        else if (V20NameHelper.IsNibling(__instance)) template_id = "civ_rat_kingdom_motto";
        else if (V20NameHelper.IsCharmaca(__instance)) template_id = "civ_alpaca_kingdom_motto";
        else if (V20NameHelper.IsHerdor(__instance)) template_id = "civ_goat_kingdom_motto";
        else if (V20NameHelper.IsRibbit(__instance)) template_id = "civ_frog_kingdom_motto";
        else if (V20NameHelper.IsGnapkin(__instance)) template_id = "civ_piranha_kingdom_motto";
        else if (V20NameHelper.IsReptiloid(__instance)) template_id = "civ_crocodile_kingdom_motto";
        else if (V20NameHelper.IsMeowmorph(__instance)) template_id = "civ_cat_kingdom_motto";
        else if (V20NameHelper.IsDunglord(__instance)) template_id = "civ_beetle_kingdom_motto";
        else if (V20NameHelper.IsArmococ(__instance)) template_id = "civ_armococ_kingdom_motto";
        else if (V20NameHelper.IsGrranth(__instance)) template_id = "civ_grranth_kingdom_motto";
        else if (V20NameHelper.IsCandyManCivilizationSource(__instance)) template_id = "civ_candy_kingdom_motto";
        else if (V20NameHelper.IsCrab(__instance)) template_id = "civ_crab_kingdom_motto";
        else if (V20NameHelper.IsTurtok(__instance)) template_id = "civ_turtle_kingdom_motto";
        else if (V20NameHelper.IsNavySeal(__instance)) template_id = "civ_seal_kingdom_motto";
        else if (V20NameHelper.IsMonkey(__instance)) template_id = "civ_monkey_kingdom_motto";
        else if (V20NameHelper.IsHopper(__instance)) template_id = "civ_hopper_kingdom_motto";
        else if (V20NameHelper.IsScorp(__instance)) template_id = "civ_scorpion_kingdom_motto";
        else if (V20NameHelper.IsCoolbeak(__instance)) template_id = "civ_coolbeak_kingdom_motto";
        else if (V20NameHelper.IsLiliarCivilizationSource(__instance)) template_id = "civ_liliar_kingdom_motto";
        else if (V20NameHelper.IsWolf(__instance)) template_id = "civ_wolf_kingdom_motto";
        else if (V20NameHelper.IsSnake(__instance)) template_id = "civ_snake_kingdom_motto";
        else if (V20NameHelper.IsCrystalCivilizationSource(__instance)) template_id = "civ_crystal_kingdom_motto";
        else if (V20NameHelper.IsCapybara(__instance)) template_id = "civ_capybara_kingdom_motto";
        else template_id = $"{race_id}_kingdom_motto";
        var generator = CN_NameGeneratorLibrary.Instance.get(template_id);
        if (generator == null) generator = CN_NameGeneratorLibrary.Instance.get("kingdom_mottos");
        if (generator == null) return true;

        var para = new Dictionary<string, string>();

        ParameterGetters.GetKingdomParameterGetter(generator.parameter_getter)(__instance, para);

        __instance.data.motto = generator.GenerateName(para);
        return true;
    }
/*
    class RenameKingdom : KingdomSetupHandler
    {
        public override void Handle(Kingdom pKingdom, bool pCiv)
        {
            if (!pCiv) return;
            if (!string.IsNullOrWhiteSpace(pKingdom.data.name)) return;

            string name_generator_id = "human_kingdom";
            if (pKingdom.race == null)
            {
                ModClass.LogWarning(
                    $"No found race for kingdom {pKingdom.id} at {pKingdom.location}, use default name generator(human).");
            }
            else
            {
                name_generator_id = pKingdom.race.name_template_kingdom;
            }

            var asset = CN_NameGeneratorLibrary.Instance.get(name_generator_id);
            if (asset == null) return;

            var para = new Dictionary<string, string>();

            ParameterGetters.GetKingdomParameterGetter(asset.parameter_getter)(pKingdom, para);

            pKingdom.data.name = asset.GenerateName(para);
        }
    }*/
}
