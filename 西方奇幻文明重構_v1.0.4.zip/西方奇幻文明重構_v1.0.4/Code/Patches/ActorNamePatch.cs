﻿using System.Collections.Generic;
using System.Reflection.Emit;
using Chinese_Name.constants;
using Chinese_Name.utils;
using HarmonyLib;
using NeoModLoader.api.attributes;

namespace Chinese_Name;

public class ActorNamePatch : IPatch
{
    public void Initialize()
    {
        Harmony harmony = new Harmony(nameof(set_actor_name));
        harmony.Patch(AccessTools.Method(typeof(Actor), nameof(Actor.getName)),
            prefix: new HarmonyMethod(AccessTools.Method(GetType(), nameof(set_actor_name))));
        harmony.Patch(AccessTools.Method(typeof(ActionLibrary), nameof(ActionLibrary.turnIntoZombie)),
            transpiler: new HarmonyMethod(AccessTools.Method(GetType(), nameof(undead_creature_name))));
        harmony.Patch(AccessTools.Method(typeof(ActionLibrary), nameof(ActionLibrary.turnIntoSkeleton)),
            transpiler: new HarmonyMethod(AccessTools.Method(GetType(), nameof(undead_creature_name))));
    }
    [Hotfixable]
private static bool set_actor_name(Actor __instance)
{
    if (!string.IsNullOrWhiteSpace(__instance.data.name)) return true;

    string raw_actor_id = __instance.asset.id ?? "";
    string normalized_actor_id = raw_actor_id.Trim().ToLowerInvariant()
        .Replace(" ", "_")
        .Replace("-", "_");

    string template_id = null;

    // V17：部分生物開智後，畫面名稱雖變成新物種，但內部 asset.id 仍可能保留原型 ID。
    // 因此不能只靠 punkcorn 字樣；「文明狀態的 unicorn」也必須視為 Punkcorn，固定走第 5 類。
    bool looks_civilized = __instance.asset.civ || normalized_actor_id.StartsWith("civ_");
    string core_race = CoreRaceFramework.FromActor(__instance);
    if (core_race != null)
    {
        template_id = CoreRaceFramework.GeneratorId(core_race, "name");
    }
    else if (V20NameHelper.IsBuffolon(__instance))
    {
        template_id = "civ_buffalo_name";
    }
    else if (V20NameHelper.IsArmaldar(__instance))
    {
        template_id = "civ_armadillo_name";
    }
    else if (V20NameHelper.IsPunkcorn(__instance))
    {
        template_id = "civ_unicorn_name";
    }
    else if (V20NameHelper.IsBaakin(__instance))
    {
        template_id = "civ_sheep_name";
    }
    else if (V20NameHelper.IsMootaur(__instance))
    {
        template_id = "civ_cow_name";
    }
    else if (V20NameHelper.IsSlypaw(__instance))
    {
        template_id = "civ_fox_name";
    }
    else if (V20NameHelper.IsPecklord(__instance))
    {
        template_id = "civ_chicken_name";
    }
    else if (V20NameHelper.IsBarkfolk(__instance))
    {
        template_id = "civ_dog_name";
    }
    else if (V20NameHelper.IsAcidGentleman(__instance))
    {
        template_id = "civ_acid_gentleman_name";
    }
    else if (V20NameHelper.IsGarlicMan(__instance))
    {
        template_id = "civ_garlic_man_name";
    }
    else if (V20NameHelper.IsMiscCivilization(__instance))
    {
        template_id = "civ_misc_name";
    }
    else if (V20NameHelper.IsLemonMan(__instance))
    {
        template_id = "civ_lemon_man_name";
    }
    else if (V20NameHelper.IsPlagueDoctor(__instance))
    {
        template_id = "civ_plague_doctor_name";
    }
    else if (V20NameHelper.IsDemon(__instance))
    {
        template_id = "civ_demon_name";
    }
    else if (V20NameHelper.IsFairy(__instance))
    {
        template_id = "civ_fairy_name";
    }
    else if (V20NameHelper.IsEvilMage(__instance))
    {
        template_id = "civ_evil_mage_name";
    }
    else if (V20NameHelper.IsAlien(__instance))
    {
        template_id = "civ_alien_name";
    }
    else if (V20NameHelper.IsWhiteMage(__instance))
    {
        template_id = "civ_white_mage_name";
    }
    else if (V20NameHelper.IsColdOne(__instance))
    {
        template_id = "civ_cold_one_name";
    }
    else if (V20NameHelper.IsAngle(__instance))
    {
        template_id = "civ_angle_name";
    }
    else if (V20NameHelper.IsSkeleton(__instance))
    {
        template_id = "civ_skeleton_name";
    }
    else if (V20NameHelper.IsSnowman(__instance))
    {
        template_id = "civ_snowman_name";
    }
    else if (V20NameHelper.IsDruid(__instance))
    {
        template_id = "civ_druid_name";
    }
    else if (V20NameHelper.IsGhost(__instance))
    {
        template_id = "civ_ghost_name";
    }
    else if (V20NameHelper.IsBandit(__instance))
    {
        template_id = "civ_bandit_name";
    }
    else if (V20NameHelper.IsJumpySkull(__instance))
    {
        template_id = "civ_jumpy_skull_name";
    }
    else if (V20NameHelper.IsFireSkull(__instance))
    {
        template_id = "civ_fire_skull_name";
    }
    else if (V20NameHelper.IsGreg(__instance))
    {
        template_id = "civ_greg_name";
    }
    else if (V20NameHelper.IsNecromancer(__instance))
    {
        template_id = "civ_necromancer_name";
    }
    else if (V20NameHelper.IsLulclaw(__instance))
    {
        template_id = "civ_hyena_name";
    }
    else if (V20NameHelper.IsNibling(__instance))
    {
        template_id = "civ_rat_name";
    }
    else if (V20NameHelper.IsCharmaca(__instance))
    {
        template_id = "civ_alpaca_name";
    }
    else if (V20NameHelper.IsHerdor(__instance))
    {
        template_id = "civ_goat_name";
    }
    else if (V20NameHelper.IsRibbit(__instance))
    {
        template_id = "civ_frog_name";
    }
    else if (V20NameHelper.IsGnapkin(__instance))

    {
        template_id = "civ_piranha_name";
    

    }

    else if (V20NameHelper.IsReptiloid(__instance))

    {
        template_id = "civ_crocodile_name";
    

    }

    else if (V20NameHelper.IsMeowmorph(__instance))
    {
        template_id = "civ_cat_name";
    }
    else if (V20NameHelper.IsDunglord(__instance))
    {
        template_id = "civ_beetle_name";
    }
    else if (V20NameHelper.IsArmococ(__instance))
    {
        template_id = "civ_armococ_name";
    }
    else if (V20NameHelper.IsGrranth(__instance))
    {
        template_id = "civ_grranth_name";
    }
    else if (V20NameHelper.IsCandyMan(__instance))
    {
        template_id = "civ_candy_name";
    }
    else if (V20NameHelper.IsCrab(__instance))
    {
        template_id = "civ_crab_name";
    }
    else if (V20NameHelper.IsTurtok(__instance))
    {
        template_id = "civ_turtle_name";
    }
    else if (normalized_actor_id == "turtle")
    {
        template_id = "turtle_name";
    }
    else if (V20NameHelper.IsNavySeal(__instance))
    {
        template_id = "civ_seal_name";
    }
    else if (normalized_actor_id == "seal")
    {
        template_id = "seal_name";
    }
    else if (V20NameHelper.IsCapybara(__instance))
    {
        template_id = "civ_capybara_name";
    }
    else if (V20NameHelper.IsCrystal(__instance))
    {
        template_id = "civ_crystal_name";
    }
    else if (V20NameHelper.IsSnake(__instance))
    {
        template_id = "civ_snake_name";
    }
    else if (V20NameHelper.IsWolf(__instance))
    {
        template_id = "civ_wolf_name";
    }
    else if (V20NameHelper.IsLiliar(__instance))
    {
        template_id = "civ_liliar_name";
    }
    else if (normalized_actor_id.Contains("punkcorn") ||
             (looks_civilized && normalized_actor_id.Contains("unicorn")))
    {
        template_id = "civ_punkcorn_name";
    }

    // 文明／有腦版本優先使用第 5 類模板。
    // 先嘗試 civ_生物ID_name，可兼容「原 ID 沒有 civ_ 前綴、但 asset.civ=true」的情況。
    else if (looks_civilized)
    {
        string civ_template_id = normalized_actor_id.StartsWith("civ_")
            ? $"{normalized_actor_id}_name"
            : $"civ_{normalized_actor_id}_name";

        if (CN_NameGeneratorLibrary.Instance.get(civ_template_id) != null)
        {
            template_id = civ_template_id;
        }
        else
        {
            string raw_template_id = $"{raw_actor_id}_name";
            if (CN_NameGeneratorLibrary.Instance.get(raw_template_id) != null)
            {
                template_id = raw_template_id;
            }
            else
            {
                string normalized_template_id = $"{normalized_actor_id}_name";
                template_id = CN_NameGeneratorLibrary.Instance.get(normalized_template_id) != null
                    ? normalized_template_id
                    : "default_name";
            }
        }
    }
    // V9 特殊路由只處理非文明版本，避免 Liliar／Bitba 有腦後仍被攔到第 2 類。
    else if (normalized_actor_id.Contains("bitba"))
    {
        template_id = "bitba_name"; // 2：魔法自然
    }
    else if ((normalized_actor_id.Contains("fire") && normalized_actor_id.Contains("elemental")) ||
             normalized_actor_id.Contains("fire_dlemental"))
    {
        template_id = "fire_elemental_name"; // 3：黑暗生物
    }
    else
    {
        string raw_template_id = $"{raw_actor_id}_name";
        if (CN_NameGeneratorLibrary.Instance.get(raw_template_id) != null)
        {
            template_id = raw_template_id;
        }
        else
        {
            string normalized_template_id = $"{normalized_actor_id}_name";
            template_id = CN_NameGeneratorLibrary.Instance.get(normalized_template_id) != null
                ? normalized_template_id
                : "default_name";
        }
    }

    var generator = CN_NameGeneratorLibrary.Instance.get(template_id);
    if (generator == null) return true;

    var para = new Dictionary<string, string>();
    ParameterGetters.GetActorParameterGetter(generator.parameter_getter)(__instance.a, para);

    __instance.data.get(DataS.family_name, out var family_name, "");
    if (string.IsNullOrEmpty(family_name))
    {
        foreach (var parent in __instance.getParents())
        {
            parent.data.get(DataS.family_name, out family_name, "");
            if (!string.IsNullOrEmpty(family_name) && parent.data.sex == ActorSex.Male) break;
        }
    }
    para[DataS.family_name_in_template] = family_name;

    __instance.data.name = generator.GenerateName(para);

    para.TryGetValue(DataS.family_name_in_template, out family_name);
    __instance.data.set(DataS.family_name, family_name);

    return true;
}

    private static IEnumerable<CodeInstruction> undead_creature_name(IEnumerable<CodeInstruction> pIntro)
    {
        var codes = new List<CodeInstruction>(pIntro);
        var idx = codes.FindIndex(x => x.opcode == OpCodes.Ldstr && (string)x.operand == "Un");
        if (idx != -1) codes[idx].operand = "亡-";
        return codes;
    }
}
