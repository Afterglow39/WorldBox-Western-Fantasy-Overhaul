﻿using System.Collections.Generic;
using Chinese_Name.utils;
using HarmonyLib;

namespace Chinese_Name;

public class SubspeciesNamePatch : IPatch
{
    private static readonly string[] s_plainAnimalSpeciesIds = { "cat", "chicken", "monkey", "sheep", "armadillo", "dog", "rabbit", "fox", "cow", "raccoon", "wolf", "rhino", "hyena", "alpaca", "goat", "bear", "buffalo", "rat", "capybara", "penguin", "ostrich", "crab", "turtle", "snake", "piranha", "scorpion", "crocodile", "frog", "seal", "unicorn" };
    private static readonly string[] s_plainSpecialPrecursorSpeciesIds = { "flower_bud", "flowerbud", "smore", "crystal_sword", "crystalsword", "garl", "acid_blob" };
    private static readonly string[] s_plainAnomalousCreatureSpeciesIds = { "bioblob", "lil_pumpkin", "assimilator" };
    private static readonly string[] s_fireElementalFormIds = {
        "fire_elemental", "fire_dlemental",
        "fire_elemental_man", "fire_elemental_blob", "fire_elemental_horse", "fire_elemental_slug", "fire_elemental_snake"
    };
    private static readonly string[] s_plainInsectSpeciesIds = { "bee", "butterfly", "grasshopper", "fly", "beetle" };
    public void Initialize()
    {
        new Harmony(nameof(set_subspecies_name)).Patch(AccessTools.Method(typeof(Subspecies), nameof(Subspecies.generateName)),
            postfix: new HarmonyMethod(GetType(), nameof(set_subspecies_name)));
    }
    private static void set_subspecies_name(Subspecies __instance)
    {
        string species_id = (__instance.species_id ?? "").Trim().ToLowerInvariant()
            .Replace(" ", "_")
            .Replace("-", "_");

        // V35.2：所有動物智慧文明共用同一套隔離判斷。
        // 裸普通物種 ID 不再能單獨命中文明亞種。
        string template_id;

        // V1.0.3 根因修正：火元素不是單一 Actor ID，而是人形、液團、火馬、火蛞蝓、焰蛇五種形態。
        // V1.0.2 只攔截 fire_elemental / fire_dlemental，因此只有部分形態會命中。
        // 現在同時檢查 Subspecies.species_id 與物件鏈內的精確形態 ID，且不因 civ=true 排除。
        string fireElementalId = null;
        foreach (string id in s_fireElementalFormIds)
        {
            if (species_id == id)
            {
                fireElementalId = id;
                break;
            }
        }
        if (fireElementalId == null)
            fireElementalId = V20NameHelper.FindKnownId(__instance, s_fireElementalFormIds);

        string core_race = CoreRaceFramework.FromSubspecies(__instance);
        if (fireElementalId != null)
            template_id = "fire_elemental_species";
        else if (core_race != null)
            template_id = CoreRaceFramework.GeneratorId(core_race, "species");
        else if (V20NameHelper.IsBuffolon(__instance))
            template_id = "civ_buffalo_species";
        else if (V20NameHelper.IsArmaldar(__instance))
            template_id = "civ_armadillo_species";
        else if (V20NameHelper.IsPunkcorn(__instance))
            template_id = "civ_unicorn_species";
        else if (V20NameHelper.IsBaakin(__instance))
            template_id = "civ_sheep_species";
        else if (V20NameHelper.IsMootaur(__instance))
            template_id = "civ_cow_species";
        else if (V20NameHelper.IsSlypaw(__instance))
            template_id = "civ_fox_species";
        else if (V20NameHelper.IsPecklord(__instance))
            template_id = "civ_chicken_species";
        else if (V20NameHelper.IsBarkfolk(__instance))
            template_id = "civ_dog_species";
        else if (V20NameHelper.IsAcidGentleman(__instance))
            template_id = "civ_acid_gentleman_species";
        else if (V20NameHelper.IsGarlicMan(__instance))
            template_id = "civ_garlic_man_species";
        else if (V20NameHelper.IsMiscCivilization(__instance))
            template_id = "civ_misc_species";
        else if (V20NameHelper.IsLemonMan(__instance))
            template_id = "civ_lemon_man_species";
        else if (V20NameHelper.IsPlagueDoctor(__instance))
            template_id = "civ_plague_doctor_species";
        else if (V20NameHelper.IsDemon(__instance))
            template_id = "civ_demon_species";
        else if (V20NameHelper.IsFairy(__instance))
            template_id = "civ_fairy_species";
        else if (V20NameHelper.IsEvilMage(__instance))
            template_id = "civ_evil_mage_species";
        else if (V20NameHelper.IsAlien(__instance))
            template_id = "civ_alien_species";
        else if (V20NameHelper.IsWhiteMage(__instance))
            template_id = "civ_white_mage_species";
        else if (V20NameHelper.IsColdOne(__instance))
            template_id = "civ_cold_one_species";
        else if (V20NameHelper.IsAngle(__instance))
            template_id = "civ_angle_species";
        else if (V20NameHelper.IsSkeleton(__instance))
            template_id = "civ_skeleton_species";
        else if (V20NameHelper.IsSnowman(__instance))
            template_id = "civ_snowman_species";
        else if (V20NameHelper.IsDruid(__instance))
            template_id = "civ_druid_species";
        else if (V20NameHelper.IsGhost(__instance))
            template_id = "civ_ghost_species";
        else if (V20NameHelper.IsBandit(__instance))
            template_id = "civ_bandit_species";
        else if (V20NameHelper.IsJumpySkull(__instance))
            template_id = "civ_jumpy_skull_species";
        else if (V20NameHelper.IsFireSkull(__instance))
            template_id = "civ_fire_skull_species";
        else if (V20NameHelper.IsGreg(__instance))
            template_id = "civ_greg_species";
        else if (V20NameHelper.IsNecromancer(__instance))
            template_id = "civ_necromancer_species";
        else if (V20NameHelper.IsLulclaw(__instance))
            template_id = "civ_hyena_species";
        else if (V20NameHelper.IsNibling(__instance))
            template_id = "civ_rat_species";
        else if (V20NameHelper.IsCharmaca(__instance))
            template_id = "civ_alpaca_species";
        else if (V20NameHelper.IsHerdor(__instance))
            template_id = "civ_goat_species";
        else if (V20NameHelper.IsRibbit(__instance))
            template_id = "civ_frog_species";
        else if (V20NameHelper.IsGnapkin(__instance))
            template_id = "civ_piranha_species";
        else if (V20NameHelper.IsReptiloid(__instance))
            template_id = "civ_crocodile_species";
        else if (V20NameHelper.IsMeowmorph(__instance))
            template_id = "civ_cat_species";
        else if (V20NameHelper.IsDunglord(__instance))
            template_id = "civ_beetle_species";
        else if (V20NameHelper.IsArmococ(__instance))
            template_id = "civ_armococ_species";
        else if (V20NameHelper.IsGrranth(__instance))
            template_id = "civ_grranth_species";
        else if (V20NameHelper.IsCandyMan(__instance))
            template_id = "civ_candy_species";
        else if (V20NameHelper.IsCrab(__instance))
            template_id = "civ_crab_species";
        else if (V20NameHelper.IsTurtok(__instance))
            template_id = "civ_turtle_species";
        else if (V20NameHelper.IsNavySeal(__instance))
            template_id = "civ_seal_species";
        else if (V20NameHelper.IsMonkey(__instance))
            template_id = "civ_monkey_species";
        else if (V20NameHelper.IsHopper(__instance))
            template_id = "civ_hopper_species";
        else if (V20NameHelper.IsScorp(__instance))
            template_id = "civ_scorpion_species";
        else if (V20NameHelper.IsCoolbeak(__instance))
            template_id = "civ_coolbeak_species";
        else if (V20NameHelper.IsLiliar(__instance))
            template_id = "civ_liliar_species";
        else if (V20NameHelper.IsWolf(__instance))
            template_id = "civ_wolf_species";
        else if (V20NameHelper.IsSnake(__instance))
            template_id = "civ_snake_species";
        else if (V20NameHelper.IsCrystal(__instance))
            template_id = "civ_crystal_species";
        else if (V20NameHelper.IsCapybara(__instance))
            template_id = "civ_capybara_species";
        else
        {
            // V72.8：沒有 civ 標記的特殊前身先使用自己的亞種；成熟／開智文明已在上方優先命中。
            string precursorId = V20NameHelper.FindOrdinaryAnimalId(__instance, s_plainSpecialPrecursorSpeciesIds);
            if (precursorId != null)
                template_id = precursorId + "_species";
            else
            {
                // V72.9：四種異常生物先使用獨立亞種；它們不與正常動物或特殊成長前身共池。
                string anomalousId = V20NameHelper.FindOrdinaryAnimalId(__instance, s_plainAnomalousCreatureSpeciesIds);
                if (anomalousId != null)
                    template_id = anomalousId + "_species";
                else
                {
                    // V73：普通小型昆蟲使用獨立 plain ID；上方 IsDunglord 仍優先攔截智慧糞甲蟲族。
                    string insectId = V20NameHelper.FindOrdinaryAnimalId(__instance, s_plainInsectSpeciesIds);
                    if (insectId != null)
                        template_id = insectId + "_species";
                    else
                    {
                        // 三批普通動物維持原本精確 plain species ID；找不到才回到 default_species。
                        string ordinaryAnimalId = V20NameHelper.FindOrdinaryAnimalId(__instance, s_plainAnimalSpeciesIds);
                        template_id = ordinaryAnimalId == null ? "default_species" : ordinaryAnimalId + "_species";
                    }
                }
            }
        }

        var generator = CN_NameGeneratorLibrary.Instance.get(template_id);
        if (generator == null) return;

        var para = new Dictionary<string, string>();

        ParameterGetters.GetSubspeciesParameterGetter(generator.parameter_getter)(__instance, para);

        __instance.data.name = generator.GenerateName(para);
    }
}
