﻿using System.Collections.Generic;
using Chinese_Name.utils;
using HarmonyLib;
using NeoModLoader.General.Event.Handlers;
using NeoModLoader.General.Event.Listeners;

namespace Chinese_Name;

public class ClanNamePatch : IPatch
{
    public void Initialize()
    {
       // ClanCreateListener.RegisterHandler(new RenameClan());
       new Harmony(nameof(set_clan_name)).Patch(AccessTools.Method(typeof(Clan), nameof(Clan.newClan)),
           postfix: new HarmonyMethod(AccessTools.Method(GetType(), nameof(set_clan_name))));
       new Harmony(nameof(set_clan_motto)).Patch(AccessTools.Method(typeof(Clan), nameof(Clan.getMotto)),
           prefix: new HarmonyMethod(AccessTools.Method(GetType(), nameof(set_clan_motto))));
    }

    // V35.3：所有動物智慧文明的氏族名稱與氏族格言，統一走 V20NameHelper。
    // 普通物種 ID 不再單獨作為文明證據。
    private static string GetCivilizationClanTemplate(object root)
    {
        string core_race = CoreRaceFramework.FromDirectObject(root);
        if (core_race != null) return CoreRaceFramework.GeneratorId(core_race, "clan");
        if (V20NameHelper.IsMonkey(root)) return "civ_monkey_clan";
        if (V20NameHelper.IsHopper(root)) return "civ_hopper_clan";
        if (V20NameHelper.IsScorp(root)) return "civ_scorpion_clan";
        if (V20NameHelper.IsCoolbeak(root)) return "civ_coolbeak_clan";
        if (V20NameHelper.IsLiliarCivilizationSource(root)) return "civ_liliar_clan";
        if (V20NameHelper.IsWolf(root)) return "civ_wolf_clan";
        if (V20NameHelper.IsSnake(root)) return "civ_snake_clan";
        if (V20NameHelper.IsCrystalCivilizationSource(root)) return "civ_crystal_clan";
        if (V20NameHelper.IsCapybara(root)) return "civ_capybara_clan";
        if (V20NameHelper.IsNavySeal(root)) return "civ_seal_clan";
        if (V20NameHelper.IsBuffolon(root)) return "civ_buffalo_clan";
        if (V20NameHelper.IsArmaldar(root)) return "civ_armadillo_clan";
        if (V20NameHelper.IsPunkcorn(root)) return "civ_unicorn_clan";
        if (V20NameHelper.IsBaakin(root)) return "civ_sheep_clan";
        if (V20NameHelper.IsMootaur(root)) return "civ_cow_clan";
        if (V20NameHelper.IsSlypaw(root)) return "civ_fox_clan";
        if (V20NameHelper.IsPecklord(root)) return "civ_chicken_clan";
        if (V20NameHelper.IsBarkfolk(root)) return "civ_dog_clan";
        if (V20NameHelper.IsAcidGentleman(root)) return "civ_acid_gentleman_clan";
        if (V20NameHelper.IsGarlicMan(root)) return "civ_garlic_man_clan";
        if (V20NameHelper.IsMiscCivilizationSource(root)) return "civ_misc_clan";
        if (V20NameHelper.IsLemonMan(root)) return "civ_lemon_man_clan";
        if (V20NameHelper.IsPlagueDoctor(root)) return "civ_plague_doctor_clan";
        if (V20NameHelper.IsDemon(root)) return "civ_demon_clan";
        if (V20NameHelper.IsFairy(root)) return "civ_fairy_clan";
        if (V20NameHelper.IsEvilMage(root)) return "civ_evil_mage_clan";
        if (V20NameHelper.IsAlien(root)) return "civ_alien_clan";
        if (V20NameHelper.IsWhiteMage(root)) return "civ_white_mage_clan";
        if (V20NameHelper.IsColdOne(root)) return "civ_cold_one_clan";
        if (V20NameHelper.IsAngle(root)) return "civ_angle_clan";
        if (V20NameHelper.IsSkeleton(root)) return "civ_skeleton_clan";
        if (V20NameHelper.IsSnowman(root)) return "civ_snowman_clan";
        if (V20NameHelper.IsDruid(root)) return "civ_druid_clan";
        if (V20NameHelper.IsGhost(root)) return "civ_ghost_clan";
        if (V20NameHelper.IsBandit(root)) return "civ_bandit_clan";
        if (V20NameHelper.IsJumpySkull(root)) return "civ_jumpy_skull_clan";
        if (V20NameHelper.IsFireSkull(root)) return "civ_fire_skull_clan";
        if (V20NameHelper.IsGreg(root)) return "civ_greg_clan";
        if (V20NameHelper.IsNecromancer(root)) return "civ_necromancer_clan";
        if (V20NameHelper.IsLulclaw(root)) return "civ_hyena_clan";
        if (V20NameHelper.IsNibling(root)) return "civ_rat_clan";
        if (V20NameHelper.IsCharmaca(root)) return "civ_alpaca_clan";
        if (V20NameHelper.IsHerdor(root)) return "civ_goat_clan";
        if (V20NameHelper.IsRibbit(root)) return "civ_frog_clan";
        if (V20NameHelper.IsGnapkin(root)) return "civ_piranha_clan";
        if (V20NameHelper.IsReptiloid(root)) return "civ_crocodile_clan";
        if (V20NameHelper.IsMeowmorph(root)) return "civ_cat_clan";
        if (V20NameHelper.IsDunglord(root)) return "civ_beetle_clan";
        if (V20NameHelper.IsArmococ(root)) return "civ_armococ_clan";
        if (V20NameHelper.IsGrranth(root)) return "civ_grranth_clan";
        if (V20NameHelper.IsCandyManCivilizationSource(root)) return "civ_candy_clan";
        if (V20NameHelper.IsCrab(root)) return "civ_crab_clan";
        if (V20NameHelper.IsTurtok(root)) return "civ_turtle_clan";
        return null;
    }

    private static string GetCivilizationClanMottoTemplate(object root)
    {
        string core_race = CoreRaceFramework.FromDirectObject(root);
        if (core_race != null) return CoreRaceFramework.GeneratorId(core_race, "clan_motto");
        if (V20NameHelper.IsMonkey(root)) return "civ_monkey_clan_motto";
        if (V20NameHelper.IsHopper(root)) return "civ_hopper_clan_motto";
        if (V20NameHelper.IsScorp(root)) return "civ_scorpion_clan_motto";
        if (V20NameHelper.IsCoolbeak(root)) return "civ_coolbeak_clan_motto";
        if (V20NameHelper.IsLiliarCivilizationSource(root)) return "civ_liliar_clan_motto";
        if (V20NameHelper.IsWolf(root)) return "civ_wolf_clan_motto";
        if (V20NameHelper.IsSnake(root)) return "civ_snake_clan_motto";
        if (V20NameHelper.IsCrystalCivilizationSource(root)) return "civ_crystal_clan_motto";
        if (V20NameHelper.IsCapybara(root)) return "civ_capybara_clan_motto";
        if (V20NameHelper.IsNavySeal(root)) return "civ_seal_clan_motto";
        if (V20NameHelper.IsBuffolon(root)) return "civ_buffalo_clan_motto";
        if (V20NameHelper.IsArmaldar(root)) return "civ_armadillo_clan_motto";
        if (V20NameHelper.IsPunkcorn(root)) return "civ_unicorn_clan_motto";
        if (V20NameHelper.IsBaakin(root)) return "civ_sheep_clan_motto";
        if (V20NameHelper.IsMootaur(root)) return "civ_cow_clan_motto";
        if (V20NameHelper.IsSlypaw(root)) return "civ_fox_clan_motto";
        if (V20NameHelper.IsPecklord(root)) return "civ_chicken_clan_motto";
        if (V20NameHelper.IsBarkfolk(root)) return "civ_dog_clan_motto";
        if (V20NameHelper.IsAcidGentleman(root)) return "civ_acid_gentleman_clan_motto";
        if (V20NameHelper.IsGarlicMan(root)) return "civ_garlic_man_clan_motto";
        if (V20NameHelper.IsMiscCivilizationSource(root)) return "civ_misc_clan_motto";
        if (V20NameHelper.IsLemonMan(root)) return "civ_lemon_man_clan_motto";
        if (V20NameHelper.IsPlagueDoctor(root)) return "civ_plague_doctor_clan_motto";
        if (V20NameHelper.IsDemon(root)) return "civ_demon_clan_motto";
        if (V20NameHelper.IsFairy(root)) return "civ_fairy_clan_motto";
        if (V20NameHelper.IsEvilMage(root)) return "civ_evil_mage_clan_motto";
        if (V20NameHelper.IsAlien(root)) return "civ_alien_clan_motto";
        if (V20NameHelper.IsWhiteMage(root)) return "civ_white_mage_clan_motto";
        if (V20NameHelper.IsColdOne(root)) return "civ_cold_one_clan_motto";
        if (V20NameHelper.IsAngle(root)) return "civ_angle_clan_motto";
        if (V20NameHelper.IsSkeleton(root)) return "civ_skeleton_clan_motto";
        if (V20NameHelper.IsSnowman(root)) return "civ_snowman_clan_motto";
        if (V20NameHelper.IsDruid(root)) return "civ_druid_clan_motto";
        if (V20NameHelper.IsGhost(root)) return "civ_ghost_clan_motto";
        if (V20NameHelper.IsBandit(root)) return "civ_bandit_clan_motto";
        if (V20NameHelper.IsJumpySkull(root)) return "civ_jumpy_skull_clan_motto";
        if (V20NameHelper.IsFireSkull(root)) return "civ_fire_skull_clan_motto";
        if (V20NameHelper.IsGreg(root)) return "civ_greg_clan_motto";
        if (V20NameHelper.IsNecromancer(root)) return "civ_necromancer_clan_motto";
        if (V20NameHelper.IsLulclaw(root)) return "civ_hyena_clan_motto";
        if (V20NameHelper.IsNibling(root)) return "civ_rat_clan_motto";
        if (V20NameHelper.IsCharmaca(root)) return "civ_alpaca_clan_motto";
        if (V20NameHelper.IsHerdor(root)) return "civ_goat_clan_motto";
        if (V20NameHelper.IsRibbit(root)) return "civ_frog_clan_motto";
        if (V20NameHelper.IsGnapkin(root)) return "civ_piranha_clan_motto";
        if (V20NameHelper.IsReptiloid(root)) return "civ_crocodile_clan_motto";
        if (V20NameHelper.IsMeowmorph(root)) return "civ_cat_clan_motto";
        if (V20NameHelper.IsDunglord(root)) return "civ_beetle_clan_motto";
        if (V20NameHelper.IsArmococ(root)) return "civ_armococ_clan_motto";
        if (V20NameHelper.IsGrranth(root)) return "civ_grranth_clan_motto";
        if (V20NameHelper.IsCandyManCivilizationSource(root)) return "civ_candy_clan_motto";
        if (V20NameHelper.IsCrab(root)) return "civ_crab_clan_motto";
        if (V20NameHelper.IsTurtok(root)) return "civ_turtle_clan_motto";
        return null;
    }

    // 專屬氏族格言尚未建立時，先回退同文明王國格言，再回退通用氏族格言。
    // 這讓 35.3 先完成路由框架，後續新增文案時不必再修改程式。
    private static string GetCivilizationKingdomMottoTemplate(object root)
    {
        string core_race = CoreRaceFramework.FromDirectObject(root);
        if (core_race != null) return CoreRaceFramework.GeneratorId(core_race, "kingdom_motto");
        if (V20NameHelper.IsMonkey(root)) return "civ_monkey_kingdom_motto";
        if (V20NameHelper.IsHopper(root)) return "civ_hopper_kingdom_motto";
        if (V20NameHelper.IsScorp(root)) return "civ_scorpion_kingdom_motto";
        if (V20NameHelper.IsCoolbeak(root)) return "civ_coolbeak_kingdom_motto";
        if (V20NameHelper.IsLiliarCivilizationSource(root)) return "civ_liliar_kingdom_motto";
        if (V20NameHelper.IsWolf(root)) return "civ_wolf_kingdom_motto";
        if (V20NameHelper.IsSnake(root)) return "civ_snake_kingdom_motto";
        if (V20NameHelper.IsCrystalCivilizationSource(root)) return "civ_crystal_kingdom_motto";
        if (V20NameHelper.IsCapybara(root)) return "civ_capybara_kingdom_motto";
        if (V20NameHelper.IsNavySeal(root)) return "civ_seal_kingdom_motto";
        if (V20NameHelper.IsBuffolon(root)) return "civ_buffalo_kingdom_motto";
        if (V20NameHelper.IsArmaldar(root)) return "civ_armadillo_kingdom_motto";
        if (V20NameHelper.IsPunkcorn(root)) return "civ_unicorn_kingdom_motto";
        if (V20NameHelper.IsBaakin(root)) return "civ_sheep_kingdom_motto";
        if (V20NameHelper.IsMootaur(root)) return "civ_cow_kingdom_motto";
        if (V20NameHelper.IsSlypaw(root)) return "civ_fox_kingdom_motto";
        if (V20NameHelper.IsPecklord(root)) return "civ_chicken_kingdom_motto";
        if (V20NameHelper.IsBarkfolk(root)) return "civ_dog_kingdom_motto";
        if (V20NameHelper.IsAcidGentleman(root)) return "civ_acid_gentleman_kingdom_motto";
        if (V20NameHelper.IsGarlicMan(root)) return "civ_garlic_man_kingdom_motto";
        if (V20NameHelper.IsMiscCivilizationSource(root)) return "civ_misc_kingdom_motto";
        if (V20NameHelper.IsLemonMan(root)) return "civ_lemon_man_kingdom_motto";
        if (V20NameHelper.IsPlagueDoctor(root)) return "civ_plague_doctor_kingdom_motto";
        if (V20NameHelper.IsDemon(root)) return "civ_demon_kingdom_motto";
        if (V20NameHelper.IsFairy(root)) return "civ_fairy_kingdom_motto";
        if (V20NameHelper.IsEvilMage(root)) return "civ_evil_mage_kingdom_motto";
        if (V20NameHelper.IsAlien(root)) return "civ_alien_kingdom_motto";
        if (V20NameHelper.IsWhiteMage(root)) return "civ_white_mage_kingdom_motto";
        if (V20NameHelper.IsColdOne(root)) return "civ_cold_one_kingdom_motto";
        if (V20NameHelper.IsAngle(root)) return "civ_angle_kingdom_motto";
        if (V20NameHelper.IsSkeleton(root)) return "civ_skeleton_kingdom_motto";
        if (V20NameHelper.IsSnowman(root)) return "civ_snowman_kingdom_motto";
        if (V20NameHelper.IsDruid(root)) return "civ_druid_kingdom_motto";
        if (V20NameHelper.IsGhost(root)) return "civ_ghost_kingdom_motto";
        if (V20NameHelper.IsBandit(root)) return "civ_bandit_kingdom_motto";
        if (V20NameHelper.IsJumpySkull(root)) return "civ_jumpy_skull_kingdom_motto";
        if (V20NameHelper.IsFireSkull(root)) return "civ_fire_skull_kingdom_motto";
        if (V20NameHelper.IsGreg(root)) return "civ_greg_kingdom_motto";
        if (V20NameHelper.IsNecromancer(root)) return "civ_necromancer_kingdom_motto";
        if (V20NameHelper.IsLulclaw(root)) return "civ_hyena_kingdom_motto";
        if (V20NameHelper.IsNibling(root)) return "civ_rat_kingdom_motto";
        if (V20NameHelper.IsCharmaca(root)) return "civ_alpaca_kingdom_motto";
        if (V20NameHelper.IsHerdor(root)) return "civ_goat_kingdom_motto";
        if (V20NameHelper.IsRibbit(root)) return "civ_frog_kingdom_motto";
        if (V20NameHelper.IsGnapkin(root)) return "civ_piranha_kingdom_motto";
        if (V20NameHelper.IsReptiloid(root)) return "civ_crocodile_kingdom_motto";
        if (V20NameHelper.IsMeowmorph(root)) return "civ_cat_kingdom_motto";
        if (V20NameHelper.IsDunglord(root)) return "civ_beetle_kingdom_motto";
        if (V20NameHelper.IsArmococ(root)) return "civ_armococ_kingdom_motto";
        if (V20NameHelper.IsGrranth(root)) return "civ_grranth_kingdom_motto";
        if (V20NameHelper.IsCandyManCivilizationSource(root)) return "civ_candy_kingdom_motto";
        if (V20NameHelper.IsCrab(root)) return "civ_crab_kingdom_motto";
        if (V20NameHelper.IsTurtok(root)) return "civ_turtle_kingdom_motto";
        return null;
    }

    private static bool set_clan_motto(Clan __instance)
    {
        if (!string.IsNullOrWhiteSpace(__instance.data.motto)) return true;

        string race_id = __instance.data.original_actor_asset;
        string template_id = GetCivilizationClanMottoTemplate(__instance);
        var generator = string.IsNullOrWhiteSpace(template_id)
            ? null
            : CN_NameGeneratorLibrary.Instance.get(template_id);

        if (generator == null)
        {
            string kingdom_motto_id = GetCivilizationKingdomMottoTemplate(__instance);
            if (!string.IsNullOrWhiteSpace(kingdom_motto_id))
                generator = CN_NameGeneratorLibrary.Instance.get(kingdom_motto_id);
        }

        if (generator == null && !string.IsNullOrWhiteSpace(race_id))
            generator = CN_NameGeneratorLibrary.Instance.get($"{race_id}_clan_motto");

        if (generator == null)
            generator = CN_NameGeneratorLibrary.Instance.get("clan_mottos");

        if (generator == null) return true;

        var para = new Dictionary<string, string>();
        ParameterGetters.GetClanParameterGetter(generator.parameter_getter)(__instance, null, para);
        __instance.data.motto = generator.GenerateName(para);
        return true;
    }

    private static void set_clan_name(Clan __instance, Actor pFounder)
    {
        if (pFounder == null) return;

        string race_id = pFounder.asset.id;
        string template_id = GetCivilizationClanTemplate(pFounder);

        if (string.IsNullOrWhiteSpace(template_id))
            template_id = $"{race_id}_clan";

        var generator = CN_NameGeneratorLibrary.Instance.get(template_id);

        // 找不到自己的模板就保留原版結果，絕不借用其他種族。
        if (generator == null) return;

        var para = new Dictionary<string, string>();
        ParameterGetters.GetClanParameterGetter(generator.parameter_getter)(__instance, pFounder, para);
        __instance.data.name = generator.GenerateName(para);
    }
/*
    class RenameClan : ClanCreateHandler
    {
        private static readonly HashSet<string> vanilla_postfix = new()
        {
            "ak", "an", "ok", "on", "uk", "un"
        };

        public override void Handle(Clan pClan, Actor pFounder)
        {
            if (!string.IsNullOrWhiteSpace(pClan.data.name) &&
                !vanilla_postfix.Contains(pClan.data.name.Trim())) return;
            if (pFounder == null) return;

            var asset = CN_NameGeneratorLibrary.Instance.get(pFounder.race.name_template_clan);
            if (asset == null) return;

            var para = new Dictionary<string, string>();

            ParameterGetters.GetClanParameterGetter(asset.parameter_getter)(pClan, pFounder, para);

            pClan.data.name = asset.GenerateName(para);
        }
    }*/
}
