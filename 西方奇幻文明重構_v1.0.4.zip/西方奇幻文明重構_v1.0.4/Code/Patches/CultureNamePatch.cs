﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using Chinese_Name.utils;

namespace Chinese_Name;

public class CultureNamePatch : IPatch
{
    private const int ScanIntervalFrames = 30;
    private const int StableScansRequired = 2;
    private const int MaxReflectionDepth = 4;
    private const int MaxEnumerableItems = 4096;

    // V67.1：不能只記錄「這個 Culture 參照曾經命名過」。WorldBox 切換地圖時
    // World.world 可能仍是同一個單例，而且 Culture 物件可能被物件池重用。
    // 因此必須同時記住當時寫入的名稱、種族與 data 參照，才能辨認舊物件已被重新初始化。
    private static readonly Dictionary<Culture, NamedCulture> s_namedCultures =
        new(new ReferenceComparer<Culture>());

    private static readonly Dictionary<Culture, PendingCulture> s_pendingCultures =
        new(new ReferenceComparer<Culture>());

    private static readonly List<Culture> s_cultureBuffer = new();

    private static bool s_enabled;
    private static int s_frameCounter;
    private static object s_lastWorld;
    private static bool s_loggedDiscoveryFailure;
    private static int s_lastObservedCultureCount;

    public void Initialize()
    {
        // V44.6：Culture.createCulture 在 WorldBox/NML 0.51.2 上無法安全 Harmony Patch，
        // CultureCreateListener 內部同樣會 Patch 該方法並觸發 Invalid IL。
        // 因此文化命名完全不再掛任何 Hook / Listener，而改由 ModClass.Update
        // 低頻掃描已建立完成的 Culture。名稱連續穩定兩次後才覆寫，避免再被原版城市名覆蓋。
        s_enabled = true;
        ModClass.LogInfo("[CULTURE] V44.6 安全輪詢已啟用；Harmony Patch=0，CultureCreateListener=0。文化名稱穩定後才套用 civ_*_culture。");
    }

    internal static void Tick()
    {
        if (!s_enabled) return;

        s_frameCounter++;
        if (s_frameCounter < ScanIntervalFrames) return;
        s_frameCounter = 0;

        try
        {
            object world = World.world;
            if (world == null) return;

            if (!ReferenceEquals(world, s_lastWorld))
            {
                s_lastWorld = world;
                ResetTracking("World.world 參照已變更");
            }

            s_cultureBuffer.Clear();
            var visited = new HashSet<object>(ReferenceComparer<object>.Instance);
            CollectCultures(world, 0, false, visited, s_cultureBuffer);

            if (s_cultureBuffer.Count == 0)
            {
                // 切換地圖時有些版本會短暫清空文化集合，但 World.world 參照不變。
                // 只要上一輪曾經看見文化，就把這個空窗視為地圖重建訊號。
                if (s_lastObservedCultureCount > 0)
                    ResetTracking("文化集合由非空轉為空，判定地圖正在重建");
                s_lastObservedCultureCount = 0;

                if (!s_loggedDiscoveryFailure)
                {
                    s_loggedDiscoveryFailure = true;
                    ModClass.LogWarning("[CULTURE] 尚未在 World.world 找到文化集合；將持續低頻重試，不影響模組其他功能。");
                }
                return;
            }

            s_loggedDiscoveryFailure = false;

            // 即使世界單例沒有更換，也要偵測 Culture 物件池是否被新地圖重用。
            DetectReusedCultures();
            s_lastObservedCultureCount = s_cultureBuffer.Count;

            for (int i = 0; i < s_cultureBuffer.Count; i++)
            {
                Culture culture = s_cultureBuffer[i];
                if (culture == null || culture.data == null || s_namedCultures.ContainsKey(culture)) continue;
                TryNameStableCulture(culture);
            }

            // 清除已消失文化的暫存，避免長時間遊戲累積無效參照。
            if (s_pendingCultures.Count > s_cultureBuffer.Count + 32)
            {
                var active = new HashSet<Culture>(s_cultureBuffer, new ReferenceComparer<Culture>());
                var remove = new List<Culture>();
                foreach (Culture culture in s_pendingCultures.Keys)
                    if (!active.Contains(culture)) remove.Add(culture);
                foreach (Culture culture in remove)
                    s_pendingCultures.Remove(culture);
            }
        }
        catch (Exception e)
        {
            // 輪詢失敗不得破壞遊戲或其他命名系統。
            ModClass.LogWarning("[CULTURE] V44.6 輪詢發生例外，本輪已略過；之後會自動重試。");
            ModClass.LogWarning(e.ToString());
        }
    }

    private static void TryNameStableCulture(Culture culture)
    {
        string currentName = culture.data.name ?? "";
        string raceId = culture.data.original_actor_asset ?? "";

        // 文化尚未完成初始化時先等待；不將半成品標成已處理。
        if (string.IsNullOrWhiteSpace(currentName) || string.IsNullOrWhiteSpace(raceId)) return;

        if (!s_pendingCultures.TryGetValue(culture, out PendingCulture pending))
        {
            s_pendingCultures[culture] = new PendingCulture(currentName, 1);
            return;
        }

        if (!string.Equals(pending.LastObservedName, currentName, StringComparison.Ordinal))
        {
            s_pendingCultures[culture] = new PendingCulture(currentName, 1);
            return;
        }

        pending.StableScans++;
        s_pendingCultures[culture] = pending;
        if (pending.StableScans < StableScansRequired) return;

        string templateId = GetCultureTemplate(culture, raceId);
        var generator = CN_NameGeneratorLibrary.Instance.get(templateId);

        if (generator == null && templateId != "default_culture")
        {
            ModClass.LogWarning($"[CULTURE] 找不到 {templateId}，回退 default_culture。race={raceId}");
            templateId = "default_culture";
            generator = CN_NameGeneratorLibrary.Instance.get(templateId);
        }

        if (generator == null)
        {
            ModClass.LogWarning("[CULTURE] 找不到 default_culture，本次保留原名並稍後重試。");
            return;
        }

        var parameters = new Dictionary<string, string>();
        ParameterGetters.GetCultureParameterGetter(generator.parameter_getter)(culture, parameters);

        string newName = generator.GenerateName(parameters);
        if (string.IsNullOrWhiteSpace(newName))
        {
            ModClass.LogWarning($"[CULTURE] {templateId} 生成空名稱，本次保留原名並稍後重試：{currentName}");
            return;
        }

        culture.data.name = newName;
        s_namedCultures[culture] = new NamedCulture(newName, raceId, culture.data);
        s_pendingCultures.Remove(culture);

        ModClass.LogInfo($"[CULTURE] source=V44.6-Polling | race={raceId} | template={templateId} | old={currentName} | new={newName}");
    }

    private static void DetectReusedCultures()
    {
        int trackedActive = 0;
        int changedTracked = 0;
        int hardChanged = 0;

        for (int i = 0; i < s_cultureBuffer.Count; i++)
        {
            Culture culture = s_cultureBuffer[i];
            if (culture == null || culture.data == null) continue;
            if (!s_namedCultures.TryGetValue(culture, out NamedCulture named)) continue;

            trackedActive++;
            string currentName = culture.data.name ?? "";
            string currentRace = culture.data.original_actor_asset ?? "";

            bool sameData = ReferenceEquals(named.DataReference, culture.data);
            bool sameRace = string.Equals(named.RaceId, currentRace, StringComparison.OrdinalIgnoreCase);
            bool sameName = string.Equals(named.AssignedName, currentName, StringComparison.Ordinal);

            if (!sameData || !sameRace) hardChanged++;
            if (!sameData || !sameRace || !sameName) changedTracked++;
        }

        // 1. data／種族已變：可確定同一 Culture 參照被物件池重新初始化。
        // 2. 至少兩個已追蹤文化同時全部失去我們寫入的名稱：視為整張地圖已更換。
        // 單一文化被玩家手動改名時不清空追蹤，避免搶回玩家自訂名稱。
        bool pooledObjectDetected = hardChanged > 0;
        bool bulkNameResetDetected = trackedActive >= 2 && changedTracked == trackedActive;
        if (pooledObjectDetected || bulkNameResetDetected)
        {
            string reason = pooledObjectDetected
                ? "偵測到 Culture/data 或種族參照被新地圖重用"
                : "多個已命名文化同時恢復為原版名稱";
            ResetTracking(reason);
        }
    }

    private static void ResetTracking(string reason)
    {
        s_namedCultures.Clear();
        s_pendingCultures.Clear();
        s_loggedDiscoveryFailure = false;
        ModClass.LogInfo($"[CULTURE] V67.1 已重建文化命名追蹤：{reason}。");
    }

    private static string GetCultureTemplate(object root, string raceId)
    {
        string templateId;
        string core_race = CoreRaceFramework.FromId(raceId);
        if (core_race != null) templateId = CoreRaceFramework.GeneratorId(core_race, "culture");
        else if (V20NameHelper.IsBuffolon(root)) templateId = "civ_buffalo_culture";
        else if (V20NameHelper.IsArmaldar(root)) templateId = "civ_armadillo_culture";
        else if (V20NameHelper.IsPunkcorn(root)) templateId = "civ_unicorn_culture";
        else if (V20NameHelper.IsBaakin(root)) templateId = "civ_sheep_culture";
        else if (V20NameHelper.IsMootaur(root)) templateId = "civ_cow_culture";
        else if (V20NameHelper.IsSlypaw(root)) templateId = "civ_fox_culture";
        else if (V20NameHelper.IsPecklord(root)) templateId = "civ_chicken_culture";
        else if (V20NameHelper.IsBarkfolk(root)) templateId = "civ_dog_culture";
        else if (V20NameHelper.IsAcidGentleman(root)) templateId = "civ_acid_gentleman_culture";
        else if (V20NameHelper.IsGarlicMan(root)) templateId = "civ_garlic_man_culture";
        else if (V20NameHelper.IsMiscCivilizationSource(root)) templateId = "civ_misc_culture";
        else if (V20NameHelper.IsLemonMan(root)) templateId = "civ_lemon_man_culture";
        else if (V20NameHelper.IsPlagueDoctor(root)) templateId = "civ_plague_doctor_culture";
        else if (V20NameHelper.IsDemon(root)) templateId = "civ_demon_culture";
        else if (V20NameHelper.IsFairy(root)) templateId = "civ_fairy_culture";
        else if (V20NameHelper.IsEvilMage(root)) templateId = "civ_evil_mage_culture";
        else if (V20NameHelper.IsAlien(root)) templateId = "civ_alien_culture";
        else if (V20NameHelper.IsWhiteMage(root)) templateId = "civ_white_mage_culture";
        else if (V20NameHelper.IsColdOne(root)) templateId = "civ_cold_one_culture";
        else if (V20NameHelper.IsAngle(root)) templateId = "civ_angle_culture";
        else if (V20NameHelper.IsSkeleton(root)) templateId = "civ_skeleton_culture";
        else if (V20NameHelper.IsSnowman(root)) templateId = "civ_snowman_culture";
        else if (V20NameHelper.IsDruid(root)) templateId = "civ_druid_culture";
        else if (V20NameHelper.IsGhost(root)) templateId = "civ_ghost_culture";
        else if (V20NameHelper.IsBandit(root)) templateId = "civ_bandit_culture";
        else if (V20NameHelper.IsJumpySkull(root)) templateId = "civ_jumpy_skull_culture";
        else if (V20NameHelper.IsFireSkull(root)) templateId = "civ_fire_skull_culture";
        else if (V20NameHelper.IsGreg(root)) templateId = "civ_greg_culture";
        else if (V20NameHelper.IsNecromancer(root)) templateId = "civ_necromancer_culture";
        else if (V20NameHelper.IsLulclaw(root)) templateId = "civ_hyena_culture";
        else if (V20NameHelper.IsNibling(root)) templateId = "civ_rat_culture";
        else if (V20NameHelper.IsCharmaca(root)) templateId = "civ_alpaca_culture";
        else if (V20NameHelper.IsHerdor(root)) templateId = "civ_goat_culture";
        else if (V20NameHelper.IsRibbit(root)) templateId = "civ_frog_culture";
        else if (V20NameHelper.IsGnapkin(root)) templateId = "civ_piranha_culture";
        else if (V20NameHelper.IsReptiloid(root)) templateId = "civ_crocodile_culture";
        else if (V20NameHelper.IsMeowmorph(root)) templateId = "civ_cat_culture";
        else if (V20NameHelper.IsDunglord(root)) templateId = "civ_beetle_culture";
        else if (V20NameHelper.IsArmococ(root)) templateId = "civ_armococ_culture";
        else if (V20NameHelper.IsGrranth(root)) templateId = "civ_grranth_culture";
        else if (V20NameHelper.IsCandyManCivilizationSource(root)) templateId = "civ_candy_culture";
        else if (V20NameHelper.IsCrab(root)) templateId = "civ_crab_culture";
        else if (V20NameHelper.IsTurtok(root)) templateId = "civ_turtle_culture";
        else if (V20NameHelper.IsNavySeal(root)) templateId = "civ_seal_culture";
        else if (V20NameHelper.IsMonkey(root)) templateId = "civ_monkey_culture";
        else if (V20NameHelper.IsHopper(root)) templateId = "civ_hopper_culture";
        else if (V20NameHelper.IsScorp(root)) templateId = "civ_scorpion_culture";
        else if (V20NameHelper.IsCoolbeak(root)) templateId = "civ_coolbeak_culture";
        else if (V20NameHelper.IsLiliarCivilizationSource(root)) templateId = "civ_liliar_culture";
        else if (V20NameHelper.IsWolf(root)) templateId = "civ_wolf_culture";
        else if (V20NameHelper.IsSnake(root)) templateId = "civ_snake_culture";
        else if (V20NameHelper.IsCrystalCivilizationSource(root)) templateId = "civ_crystal_culture";
        else if (V20NameHelper.IsCapybara(root)) templateId = "civ_capybara_culture";
        else templateId = string.IsNullOrWhiteSpace(raceId) ? "default_culture" : $"{NormalizeId(raceId)}_culture";
        return templateId;
    }

    private static string NormalizeId(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "";
        return value.Trim().ToLowerInvariant().Replace(" ", "_").Replace("-", "_");
    }

    private static void CollectCultures(
        object node,
        int depth,
        bool insideCultureBranch,
        HashSet<object> visited,
        List<Culture> output)
    {
        if (node == null || depth > MaxReflectionDepth) return;
        if (node is string || node.GetType().IsPrimitive || node.GetType().IsEnum) return;

        if (node is Culture culture)
        {
            if (!output.Contains(culture)) output.Add(culture);
            return;
        }

        if (!visited.Add(node)) return;

        if (node is IDictionary dictionary)
        {
            int count = 0;
            foreach (DictionaryEntry entry in dictionary)
            {
                CollectCultures(entry.Value, depth + 1, true, visited, output);
                if (++count >= MaxEnumerableItems) break;
            }
            return;
        }

        if (node is IEnumerable enumerable)
        {
            int count = 0;
            foreach (object item in enumerable)
            {
                CollectCultures(item, depth + 1, true, visited, output);
                if (++count >= MaxEnumerableItems) break;
            }
            return;
        }

        Type type = node.GetType();
        foreach (MemberInfo member in GetInstanceMembers(type))
        {
            Type memberType;
            string memberName = member.Name ?? "";

            if (member is FieldInfo field)
                memberType = field.FieldType;
            else if (member is PropertyInfo property)
            {
                if (property.GetIndexParameters().Length != 0 || !property.CanRead) continue;
                memberType = property.PropertyType;
            }
            else continue;

            bool cultureHint = ContainsCultureHint(memberName) || ContainsCultureHint(memberType?.Name);
            bool collectionHint = typeof(IEnumerable).IsAssignableFrom(memberType) || IsCollectionMemberName(memberName);

            // 世界根節點只進入名稱／型別明確與 culture 有關的分支。
            // 進入文化管理器後，才允許展開 list、dict、items 等容器。
            if (!insideCultureBranch && !cultureHint) continue;
            if (insideCultureBranch && !cultureHint && !collectionHint && depth >= 2) continue;

            object value;
            try
            {
                value = member is FieldInfo f ? f.GetValue(node) : ((PropertyInfo)member).GetValue(node, null);
            }
            catch
            {
                continue;
            }

            if (value == null || value is string) continue;
            CollectCultures(value, depth + 1, insideCultureBranch || cultureHint, visited, output);
        }
    }

    private static IEnumerable<MemberInfo> GetInstanceMembers(Type type)
    {
        const BindingFlags flags = BindingFlags.Instance |
                                   BindingFlags.Public |
                                   BindingFlags.NonPublic |
                                   BindingFlags.DeclaredOnly;

        for (Type current = type; current != null && current != typeof(object); current = current.BaseType)
        {
            FieldInfo[] fields;
            PropertyInfo[] properties;
            try { fields = current.GetFields(flags); }
            catch { fields = Array.Empty<FieldInfo>(); }
            try { properties = current.GetProperties(flags); }
            catch { properties = Array.Empty<PropertyInfo>(); }

            for (int i = 0; i < fields.Length; i++) yield return fields[i];
            for (int i = 0; i < properties.Length; i++) yield return properties[i];
        }
    }

    private static bool ContainsCultureHint(string value)
    {
        return !string.IsNullOrWhiteSpace(value) &&
               value.IndexOf("culture", StringComparison.OrdinalIgnoreCase) >= 0;
    }

    private static bool IsCollectionMemberName(string value)
    {
        if (string.IsNullOrWhiteSpace(value)) return false;
        string name = value.Trim().ToLowerInvariant();
        return name == "list" || name == "items" || name == "values" || name == "dict" ||
               name == "dictionary" || name == "objects" || name == "all" || name == "data" ||
               name.Contains("list") || name.Contains("item") || name.Contains("value") ||
               name.Contains("dict") || name.Contains("object");
    }

    private readonly struct NamedCulture
    {
        internal readonly string AssignedName;
        internal readonly string RaceId;
        internal readonly object DataReference;

        internal NamedCulture(string assignedName, string raceId, object dataReference)
        {
            AssignedName = assignedName ?? "";
            RaceId = raceId ?? "";
            DataReference = dataReference;
        }
    }

    private struct PendingCulture
    {
        internal string LastObservedName;
        internal int StableScans;

        internal PendingCulture(string lastObservedName, int stableScans)
        {
            LastObservedName = lastObservedName;
            StableScans = stableScans;
        }
    }

    private sealed class ReferenceComparer<T> : IEqualityComparer<T> where T : class
    {
        internal static readonly ReferenceComparer<T> Instance = new();

        public bool Equals(T x, T y) => ReferenceEquals(x, y);
        public int GetHashCode(T obj) => obj == null ? 0 : RuntimeHelpers.GetHashCode(obj);
    }
}
