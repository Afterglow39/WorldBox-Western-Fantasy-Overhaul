﻿using System.Collections.Generic;
using HarmonyLib;

namespace Chinese_Name;

public class ArmyNamePatch : IPatch
{
    public void Initialize()
    {
        // WorldBox 0.51 的軍隊名稱是在 Army.generateName 內產生。
        // V20 掃描多個候選方法，實際上沒有穩定攔截到正確入口；V21 改為精準 Patch。
        new Harmony("Chinese_Name.v22.civilization_army").Patch(
            AccessTools.Method(typeof(Army), nameof(Army.generateName)),
            postfix: new HarmonyMethod(AccessTools.Method(typeof(ArmyNamePatch), nameof(RenameArmy))));
    }

    private static void RenameArmy(Army __instance, Kingdom pKingdom)
    {
        if (__instance == null) return;

        Kingdom kingdom = pKingdom ?? __instance.getKingdom();
        string core_race = CoreRaceFramework.FromKingdom(kingdom);
        string generatorId = core_race == null ? null : CoreRaceFramework.GeneratorId(core_race, "army");
        if (generatorId == null && (V20NameHelper.IsBuffolon(kingdom) || V20NameHelper.IsBuffolon(__instance)))
            generatorId = "civ_buffalo_army";
        else if (V20NameHelper.IsArmaldar(kingdom) || V20NameHelper.IsArmaldar(__instance))
            generatorId = "civ_armadillo_army";
        else if (V20NameHelper.IsPunkcorn(kingdom) || V20NameHelper.IsPunkcorn(__instance))
            generatorId = "civ_unicorn_army";
        else if (V20NameHelper.IsBaakin(kingdom) || V20NameHelper.IsBaakin(__instance))
            generatorId = "civ_sheep_army";
        else if (V20NameHelper.IsMootaur(kingdom) || V20NameHelper.IsMootaur(__instance))
            generatorId = "civ_cow_army";
        else if (V20NameHelper.IsSlypaw(kingdom) || V20NameHelper.IsSlypaw(__instance))
            generatorId = "civ_fox_army";
        else if (V20NameHelper.IsPecklord(kingdom) || V20NameHelper.IsPecklord(__instance))
            generatorId = "civ_chicken_army";
        else if (V20NameHelper.IsBarkfolk(kingdom) || V20NameHelper.IsBarkfolk(__instance))
            generatorId = "civ_dog_army";
        else if (V20NameHelper.IsAcidGentleman(kingdom) || V20NameHelper.IsAcidGentleman(__instance))
            generatorId = "civ_acid_gentleman_army";
        else if (V20NameHelper.IsGarlicMan(kingdom) || V20NameHelper.IsGarlicMan(__instance))
            generatorId = "civ_garlic_man_army";
        else if (V20NameHelper.IsMiscCivilizationSource(kingdom) || V20NameHelper.IsMiscCivilizationSource(__instance))
            generatorId = "civ_misc_army";
        else if (V20NameHelper.IsLemonMan(kingdom) || V20NameHelper.IsLemonMan(__instance))
            generatorId = "civ_lemon_man_army";
        else if (V20NameHelper.IsPlagueDoctor(kingdom) || V20NameHelper.IsPlagueDoctor(__instance))
            generatorId = "civ_plague_doctor_army";
        else if (V20NameHelper.IsDemon(kingdom) || V20NameHelper.IsDemon(__instance))
            generatorId = "civ_demon_army";
        else if (V20NameHelper.IsFairy(kingdom) || V20NameHelper.IsFairy(__instance))
            generatorId = "civ_fairy_army";
        else if (V20NameHelper.IsEvilMage(kingdom) || V20NameHelper.IsEvilMage(__instance))
            generatorId = "civ_evil_mage_army";
        else if (V20NameHelper.IsAlien(kingdom) || V20NameHelper.IsAlien(__instance))
            generatorId = "civ_alien_army";
        else if (V20NameHelper.IsWhiteMage(kingdom) || V20NameHelper.IsWhiteMage(__instance))
            generatorId = "civ_white_mage_army";
        else if (V20NameHelper.IsColdOne(kingdom) || V20NameHelper.IsColdOne(__instance))
            generatorId = "civ_cold_one_army";
        else if (V20NameHelper.IsAngle(kingdom) || V20NameHelper.IsAngle(__instance))
            generatorId = "civ_angle_army";
        else if (V20NameHelper.IsSkeleton(kingdom) || V20NameHelper.IsSkeleton(__instance))
            generatorId = "civ_skeleton_army";
        else if (V20NameHelper.IsSnowman(kingdom) || V20NameHelper.IsSnowman(__instance))
            generatorId = "civ_snowman_army";
        else if (V20NameHelper.IsDruid(kingdom) || V20NameHelper.IsDruid(__instance))
            generatorId = "civ_druid_army";
        else if (V20NameHelper.IsGhost(kingdom) || V20NameHelper.IsGhost(__instance))
            generatorId = "civ_ghost_army";
        else if (V20NameHelper.IsBandit(kingdom) || V20NameHelper.IsBandit(__instance))
            generatorId = "civ_bandit_army";
        else if (V20NameHelper.IsJumpySkull(kingdom) || V20NameHelper.IsJumpySkull(__instance))
            generatorId = "civ_jumpy_skull_army";
        else if (V20NameHelper.IsFireSkull(kingdom) || V20NameHelper.IsFireSkull(__instance))
            generatorId = "civ_fire_skull_army";
        else if (V20NameHelper.IsGreg(kingdom) || V20NameHelper.IsGreg(__instance))
            generatorId = "civ_greg_army";
        else if (V20NameHelper.IsNecromancer(kingdom) || V20NameHelper.IsNecromancer(__instance))
            generatorId = "civ_necromancer_army";
        else if (V20NameHelper.IsLulclaw(kingdom) || V20NameHelper.IsLulclaw(__instance))
            generatorId = "civ_hyena_army";
        else if (V20NameHelper.IsNibling(kingdom) || V20NameHelper.IsNibling(__instance))
            generatorId = "civ_rat_army";
        else if (V20NameHelper.IsCharmaca(kingdom) || V20NameHelper.IsCharmaca(__instance))
            generatorId = "civ_alpaca_army";
        else if (V20NameHelper.IsHerdor(kingdom) || V20NameHelper.IsHerdor(__instance))
            generatorId = "civ_goat_army";
        else if (V20NameHelper.IsRibbit(kingdom) || V20NameHelper.IsRibbit(__instance))
            generatorId = "civ_frog_army";
        else if (V20NameHelper.IsGnapkin(kingdom) || V20NameHelper.IsGnapkin(__instance))
            generatorId = "civ_piranha_army";
        else if (V20NameHelper.IsReptiloid(kingdom) || V20NameHelper.IsReptiloid(__instance))
            generatorId = "civ_crocodile_army";
        else if (V20NameHelper.IsMeowmorph(kingdom) || V20NameHelper.IsMeowmorph(__instance))
            generatorId = "civ_cat_army";
        else if (V20NameHelper.IsDunglord(kingdom) || V20NameHelper.IsDunglord(__instance))
            generatorId = "civ_beetle_army";
        else if (V20NameHelper.IsArmococ(kingdom) || V20NameHelper.IsArmococ(__instance))
            generatorId = "civ_armococ_army";
        else if (V20NameHelper.IsGrranth(kingdom) || V20NameHelper.IsGrranth(__instance))
            generatorId = "civ_grranth_army";
        else if (V20NameHelper.IsCandyManCivilizationSource(kingdom) || V20NameHelper.IsCandyManCivilizationSource(__instance))
            generatorId = "civ_candy_army";
        else if (V20NameHelper.IsCrab(kingdom) || V20NameHelper.IsCrab(__instance))
            generatorId = "civ_crab_army";
        else if (V20NameHelper.IsTurtok(kingdom) || V20NameHelper.IsTurtok(__instance))
            generatorId = "civ_turtle_army";
        else if (V20NameHelper.IsNavySeal(kingdom) || V20NameHelper.IsNavySeal(__instance))
            generatorId = "civ_seal_army";
        else if (V20NameHelper.IsMonkey(kingdom) || V20NameHelper.IsMonkey(__instance))
            generatorId = "civ_monkey_army";
        else if (V20NameHelper.IsHopper(kingdom) || V20NameHelper.IsHopper(__instance))
            generatorId = "civ_hopper_army";
        else if (V20NameHelper.IsScorp(kingdom) || V20NameHelper.IsScorp(__instance))
            generatorId = "civ_scorpion_army";
        else if (V20NameHelper.IsCoolbeak(kingdom) || V20NameHelper.IsCoolbeak(__instance))
            generatorId = "civ_coolbeak_army";
        else if (V20NameHelper.IsLiliarCivilizationSource(kingdom) || V20NameHelper.IsLiliarCivilizationSource(__instance))
            generatorId = "civ_liliar_army";
        else if (V20NameHelper.IsWolf(kingdom) || V20NameHelper.IsWolf(__instance))
            generatorId = "civ_wolf_army";
        else if (V20NameHelper.IsSnake(kingdom) || V20NameHelper.IsSnake(__instance))
            generatorId = "civ_snake_army";
        else if (V20NameHelper.IsCrystalCivilizationSource(kingdom) || V20NameHelper.IsCrystalCivilizationSource(__instance))
            generatorId = "civ_crystal_army";
        else if (V20NameHelper.IsCapybara(kingdom) || V20NameHelper.IsCapybara(__instance))
            generatorId = "civ_capybara_army";
        if (generatorId == null) return;

        CN_NameGeneratorAsset generator = CN_NameGeneratorLibrary.Instance.get(generatorId);
        if (generator == null) return;

        Dictionary<string, string> para = new();
        if (kingdom != null && kingdom.data != null)
        {
            para["kingdom"] = kingdom.data.name;
        }

        __instance.data.name = generator.GenerateName(para);
    }
}
