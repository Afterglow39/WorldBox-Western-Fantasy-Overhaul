using System.Collections.Generic;
using Chinese_Name.utils;
using HarmonyLib;
using NeoModLoader.General.Event.Handlers;
using NeoModLoader.General.Event.Listeners;

namespace Chinese_Name;

public class WarNamePatch : IPatch
{
    public void Initialize()
    {
        new Harmony(nameof(set_war_name)).Patch(AccessTools.Method(typeof(WarManager), nameof(WarManager.newWar)),
            postfix: new HarmonyMethod(typeof(WarNamePatch), nameof(set_war_name)));
        WarStartListener.RegisterHandler(new RenameWar());
    }

    private static string GetGeneratorId(War pWar, WarTypeAsset pType)
    {
        string suffix = "conquest";
        string id = pType?.name_template ?? "war_conquest";
        if (id.StartsWith("war_")) suffix = id.Substring(4);
        Kingdom attacker_kingdom = pWar?.main_attacker;
        string core_race = CoreRaceFramework.FromKingdom(attacker_kingdom);
        if (core_race != null) return CoreRaceFramework.GeneratorId(core_race, $"war_{suffix}");
        object attacker = attacker_kingdom;
        if (V20NameHelper.IsBuffolon(attacker)) return $"civ_buffalo_war_{suffix}";
        if (V20NameHelper.IsArmaldar(attacker)) return $"civ_armadillo_war_{suffix}";
        if (V20NameHelper.IsPunkcorn(attacker)) return $"civ_unicorn_war_{suffix}";
        if (V20NameHelper.IsBaakin(attacker)) return $"civ_sheep_war_{suffix}";
        if (V20NameHelper.IsMootaur(attacker)) return $"civ_cow_war_{suffix}";
        if (V20NameHelper.IsSlypaw(attacker)) return $"civ_fox_war_{suffix}";
        if (V20NameHelper.IsPecklord(attacker)) return $"civ_chicken_war_{suffix}";
        if (V20NameHelper.IsBarkfolk(attacker)) return $"civ_dog_war_{suffix}";
        if (V20NameHelper.IsAcidGentleman(attacker)) return $"civ_acid_gentleman_war_{suffix}";
        if (V20NameHelper.IsGarlicMan(attacker)) return $"civ_garlic_man_war_{suffix}";
        if (V20NameHelper.IsLemonMan(attacker)) return $"civ_lemon_man_war_{suffix}";
        if (V20NameHelper.IsPlagueDoctor(attacker)) return $"civ_plague_doctor_war_{suffix}";
        if (V20NameHelper.IsDemon(attacker)) return $"civ_demon_war_{suffix}";
        if (V20NameHelper.IsFairy(attacker)) return $"civ_fairy_war_{suffix}";
        if (V20NameHelper.IsEvilMage(attacker)) return $"civ_evil_mage_war_{suffix}";
        if (V20NameHelper.IsAlien(attacker)) return $"civ_alien_war_{suffix}";
        if (V20NameHelper.IsWhiteMage(attacker)) return $"civ_white_mage_war_{suffix}";
        if (V20NameHelper.IsColdOne(attacker)) return $"civ_cold_one_war_{suffix}";
        if (V20NameHelper.IsAngle(attacker)) return $"civ_angle_war_{suffix}";
        if (V20NameHelper.IsSkeleton(attacker)) return $"civ_skeleton_war_{suffix}";
        if (V20NameHelper.IsSnowman(attacker)) return $"civ_snowman_war_{suffix}";
        if (V20NameHelper.IsDruid(attacker)) return $"civ_druid_war_{suffix}";
        if (V20NameHelper.IsGhost(attacker)) return $"civ_ghost_war_{suffix}";
        if (V20NameHelper.IsBandit(attacker)) return $"civ_bandit_war_{suffix}";
        if (V20NameHelper.IsJumpySkull(attacker)) return $"civ_jumpy_skull_war_{suffix}";
        if (V20NameHelper.IsFireSkull(attacker)) return $"civ_fire_skull_war_{suffix}";
        if (V20NameHelper.IsGreg(attacker)) return $"civ_greg_war_{suffix}";
        if (V20NameHelper.IsNecromancer(attacker)) return $"civ_necromancer_war_{suffix}";
        if (V20NameHelper.IsLulclaw(attacker)) return $"civ_hyena_war_{suffix}";
        if (V20NameHelper.IsNibling(attacker)) return $"civ_rat_war_{suffix}";
        if (V20NameHelper.IsCharmaca(attacker)) return $"civ_alpaca_war_{suffix}";
        if (V20NameHelper.IsHerdor(attacker)) return $"civ_goat_war_{suffix}";
        if (V20NameHelper.IsRibbit(attacker)) return $"civ_frog_war_{suffix}";
        if (V20NameHelper.IsGnapkin(attacker)) return $"civ_piranha_war_{suffix}";
        if (V20NameHelper.IsReptiloid(attacker)) return $"civ_crocodile_war_{suffix}";
        if (V20NameHelper.IsMeowmorph(attacker)) return $"civ_cat_war_{suffix}";
        if (V20NameHelper.IsDunglord(attacker)) return $"civ_beetle_war_{suffix}";
        if (V20NameHelper.IsArmococ(attacker)) return $"civ_armococ_war_{suffix}";
        if (V20NameHelper.IsGrranth(attacker)) return $"civ_grranth_war_{suffix}";
        if (V20NameHelper.IsCandyManCivilizationSource(attacker)) return $"civ_candy_war_{suffix}";
        if (V20NameHelper.IsCrab(attacker)) return $"civ_crab_war_{suffix}";
        if (V20NameHelper.IsTurtok(attacker)) return $"civ_turtle_war_{suffix}";
        if (V20NameHelper.IsNavySeal(attacker)) return $"civ_seal_war_{suffix}";
        if (V20NameHelper.IsMonkey(attacker)) return $"civ_monkey_war_{suffix}";
        if (V20NameHelper.IsHopper(attacker)) return $"civ_rabbit_war_{suffix}";
        if (V20NameHelper.IsScorp(attacker)) return $"civ_scorpion_war_{suffix}";
        if (V20NameHelper.IsCoolbeak(attacker)) return $"civ_coolbeak_war_{suffix}";
        if (V20NameHelper.IsLiliarCivilizationSource(attacker)) return $"civ_liliar_war_{suffix}";
        if (V20NameHelper.IsWolf(attacker)) return $"civ_wolf_war_{suffix}";
        if (V20NameHelper.IsSnake(attacker)) return $"civ_snake_war_{suffix}";
        if (V20NameHelper.IsCrystalCivilizationSource(attacker)) return $"civ_crystal_war_{suffix}";
        if (V20NameHelper.IsCapybara(attacker)) return $"civ_capybara_war_{suffix}";
        return id;
    }

    private static void Rename(War pWar, WarTypeAsset pType)
    {
        if (pWar == null) return;
        if (pWar.main_defender != null && pWar.main_defender.getAge() <= 1) pType = WarTypeLibrary.rebellion;
        string generatorId = GetGeneratorId(pWar, pType);
        var generator = CN_NameGeneratorLibrary.Instance.get(generatorId) ?? CN_NameGeneratorLibrary.Instance.get(pType.name_template);
        if (generator == null) return;
        var para = new Dictionary<string, string>();
        ParameterGetters.GetWarParameterGetter(generator.parameter_getter)(pWar, para);
        pWar.data.name = generator.GenerateName(para);
    }

    private static void set_war_name(War __result, Kingdom pAttacker, Kingdom pDefender, WarTypeAsset pType) => Rename(__result, pType);

    class RenameWar : WarStartHandler
    {
        public override void Handle(War pWar, Kingdom pAttacker, Kingdom pDefender, WarTypeAsset pWarType)
        {
            if (!string.IsNullOrWhiteSpace(pWar.data.name)) return;
            Rename(pWar, pWarType);
        }
    }
}
