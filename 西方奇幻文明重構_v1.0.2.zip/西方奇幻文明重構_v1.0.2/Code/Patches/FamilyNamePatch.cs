using System;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.CompilerServices;
using HarmonyLib;

namespace Chinese_Name;

public class FamilyNamePatch : IPatch
{
    private static Type s_familyType;
    private static readonly string[] s_plainAnimalFamilyIds = { "cat", "chicken", "monkey", "sheep", "armadillo", "dog", "rabbit", "fox", "cow", "raccoon", "wolf", "rhino", "hyena", "alpaca", "goat", "bear", "buffalo", "rat", "capybara", "penguin", "ostrich", "crab", "turtle", "snake", "piranha", "scorpion", "crocodile", "frog", "seal", "unicorn" };
    private static readonly string[] s_plainSpecialPrecursorFamilyIds = { "flower_bud", "flowerbud", "smore", "crystal_sword", "crystalsword", "garl", "acid_blob" };
    private static readonly string[] s_plainAnomalousCreatureFamilyIds = { "bioblob", "lil_pumpkin", "assimilator", "fire_elemental", "fire_dlemental" };
    private static readonly string[] s_plainInsectFamilyIds = { "bee", "butterfly", "grasshopper", "fly", "beetle" };
    private sealed class CoreRaceMemory
    {
        internal readonly string Race;
        internal CoreRaceMemory(string race) { Race = race; }
    }
    private static readonly ConditionalWeakTable<object, CoreRaceMemory> s_coreRaceMemory = new();

    public void Initialize()
    {
        Type type = AccessTools.TypeByName("Family");
        if (type == null) type = AccessTools.TypeByName("ActorFamily");
        if (type == null)
        {
            ModClass.LogWarning("[FAMILY] 找不到 Family / ActorFamily 類型，家庭自訂命名已停用。與其他名稱系統互不影響。");
            return;
        }

        s_familyType = type;

        // V44.4 關鍵修正：只檢查 Family 類別自己宣告的方法。
        // 舊版 GetMethods 沒有 DeclaredOnly，會把共同基底類別的 setup / setName / generateName 也抓進來。
        // 一旦那個共同方法由 Culture 等其他物件呼叫，RenameFamily 就會把文化名稱改成 civ_*_family，
        // 因而出現「晨湖家、百合門第、霧橋譜系」這類家庭名稱覆寫文化的現象。
        const BindingFlags flags = BindingFlags.Instance |
                                   BindingFlags.Public |
                                   BindingFlags.NonPublic |
                                   BindingFlags.DeclaredOnly;

        string[] candidates = { "newFamily", "createFamily", "setup", "setName", "generateName" };
        var patched = new HashSet<MethodBase>();
        int patchedCount = 0;

        foreach (string name in candidates)
        {
            foreach (MethodInfo method in type.GetMethods(flags))
            {
                if (method.Name != name) continue;
                if (method.DeclaringType != type) continue;
                if (!patched.Add(method)) continue;

                try
                {
                    new Harmony("Chinese_Name.v44_4.family." + name + "." + method.MetadataToken).Patch(
                        method,
                        postfix: new HarmonyMethod(typeof(FamilyNamePatch), nameof(RenameFamily)));
                    patchedCount++;
                }
                catch (Exception e)
                {
                    ModClass.LogWarning($"[FAMILY] 無法 Patch {type.FullName}.{method.Name}，已略過：{e.Message}");
                }
            }
        }

        ModClass.LogInfo($"[FAMILY] V44.4 安全路由已啟用；僅 Patch {type.FullName} 自己宣告的方法，共 {patchedCount} 個。Inherited methods=0。");
    }

    private static void RenameFamily(object __instance, object[] __args)
    {
        if (__instance == null || s_familyType == null) return;

        // 第二層保護：即使未來反射或 Harmony 行為改變，也只允許真正的 Family / ActorFamily 實例進入。
        // Culture、Clan、Kingdom 等物件一律不得使用家庭 Generator。
        if (!s_familyType.IsInstanceOfType(__instance))
        {
            ModClass.LogWarning($"[FAMILY] 已阻止非家庭物件進入家庭命名：{__instance.GetType().FullName}");
            return;
        }

        string core_race = CoreRaceFramework.FromArguments(__args);
        if (core_race != null)
        {
            s_coreRaceMemory.Remove(__instance);
            s_coreRaceMemory.Add(__instance, new CoreRaceMemory(core_race));
        }
        else if (s_coreRaceMemory.TryGetValue(__instance, out CoreRaceMemory memory))
        {
            core_race = memory.Race;
        }
        else
        {
            core_race = CoreRaceFramework.FromDirectObject(__instance);
        }

        string generatorId = core_race == null ? null : CoreRaceFramework.GeneratorId(core_race, "family");
        if (generatorId == null && V20NameHelper.IsBuffolon(__instance)) generatorId = "civ_buffalo_family";
        else if (V20NameHelper.IsArmaldar(__instance)) generatorId = "civ_armadillo_family";
        else if (V20NameHelper.IsPunkcorn(__instance)) generatorId = "civ_unicorn_family";
        else if (V20NameHelper.IsBaakin(__instance)) generatorId = "civ_sheep_family";
        else if (V20NameHelper.IsMootaur(__instance)) generatorId = "civ_cow_family";
        else if (V20NameHelper.IsSlypaw(__instance)) generatorId = "civ_fox_family";
        else if (V20NameHelper.IsPecklord(__instance)) generatorId = "civ_chicken_family";
        else if (V20NameHelper.IsBarkfolk(__instance)) generatorId = "civ_dog_family";
        else if (V20NameHelper.IsAcidGentleman(__instance)) generatorId = "civ_acid_gentleman_family";
        else if (V20NameHelper.IsGarlicMan(__instance)) generatorId = "civ_garlic_man_family";
        else if (V20NameHelper.IsLemonMan(__instance)) generatorId = "civ_lemon_man_family";
        else if (V20NameHelper.IsPlagueDoctor(__instance)) generatorId = "civ_plague_doctor_family";
        else if (V20NameHelper.IsDemon(__instance)) generatorId = "civ_demon_family";
        else if (V20NameHelper.IsFairy(__instance)) generatorId = "civ_fairy_family";
        else if (V20NameHelper.IsEvilMage(__instance)) generatorId = "civ_evil_mage_family";
        else if (V20NameHelper.IsAlien(__instance)) generatorId = "civ_alien_family";
        else if (V20NameHelper.IsWhiteMage(__instance)) generatorId = "civ_white_mage_family";
        else if (V20NameHelper.IsColdOne(__instance)) generatorId = "civ_cold_one_family";
        else if (V20NameHelper.IsAngle(__instance)) generatorId = "civ_angle_family";
        else if (V20NameHelper.IsSkeleton(__instance)) generatorId = "civ_skeleton_family";
        else if (V20NameHelper.IsSnowman(__instance)) generatorId = "civ_snowman_family";
        else if (V20NameHelper.IsDruid(__instance)) generatorId = "civ_druid_family";
        else if (V20NameHelper.IsGhost(__instance)) generatorId = "civ_ghost_family";
        else if (V20NameHelper.IsBandit(__instance)) generatorId = "civ_bandit_family";
        else if (V20NameHelper.IsJumpySkull(__instance)) generatorId = "civ_jumpy_skull_family";
        else if (V20NameHelper.IsFireSkull(__instance)) generatorId = "civ_fire_skull_family";
        else if (V20NameHelper.IsGreg(__instance)) generatorId = "civ_greg_family";
        else if (V20NameHelper.IsNecromancer(__instance)) generatorId = "civ_necromancer_family";
        else if (V20NameHelper.IsLulclaw(__instance)) generatorId = "civ_hyena_family";
        else if (V20NameHelper.IsNibling(__instance)) generatorId = "civ_rat_family";
        else if (V20NameHelper.IsCharmaca(__instance)) generatorId = "civ_alpaca_family";
        else if (V20NameHelper.IsHerdor(__instance)) generatorId = "civ_goat_family";
        else if (V20NameHelper.IsRibbit(__instance)) generatorId = "civ_frog_family";
        else if (V20NameHelper.IsGnapkin(__instance)) generatorId = "civ_piranha_family";
        else if (V20NameHelper.IsReptiloid(__instance)) generatorId = "civ_crocodile_family";
        else if (V20NameHelper.IsMeowmorph(__instance)) generatorId = "civ_cat_family";
        else if (V20NameHelper.IsDunglord(__instance)) generatorId = "civ_beetle_family";
        else if (V20NameHelper.IsArmococ(__instance)) generatorId = "civ_armococ_family";
        else if (V20NameHelper.IsGrranth(__instance)) generatorId = "civ_grranth_family";
        else if (V20NameHelper.IsCandyMan(__instance)) generatorId = "civ_candy_family";
        else if (V20NameHelper.IsCrab(__instance)) generatorId = "civ_crab_family";
        else if (V20NameHelper.IsTurtok(__instance)) generatorId = "civ_turtle_family";
        else if (V20NameHelper.IsNavySeal(__instance)) generatorId = "civ_seal_family";
        else if (V20NameHelper.IsMonkey(__instance)) generatorId = "civ_monkey_family";
        else if (V20NameHelper.IsHopper(__instance)) generatorId = "civ_hopper_family";
        else if (V20NameHelper.IsScorp(__instance)) generatorId = "civ_scorpion_family";
        else if (V20NameHelper.IsCoolbeak(__instance)) generatorId = "civ_coolbeak_family";
        else if (V20NameHelper.IsLiliar(__instance)) generatorId = "civ_liliar_family";
        else if (V20NameHelper.IsWolf(__instance)) generatorId = "civ_wolf_family";
        else if (V20NameHelper.IsSnake(__instance)) generatorId = "civ_snake_family";
        else if (V20NameHelper.IsCrystal(__instance)) generatorId = "civ_crystal_family";
        else if (V20NameHelper.IsCapybara(__instance)) generatorId = "civ_capybara_family";

        // V72.8：成熟文明判斷仍在最前面；只有沒有 civ 標記的前身形態，才使用自己的簡潔家庭名稱。
        if (generatorId == null)
        {
            string precursorId = V20NameHelper.FindOrdinaryAnimalId(__instance, s_plainSpecialPrecursorFamilyIds);
            if (precursorId == null && __args != null)
            {
                foreach (object arg in __args)
                {
                    precursorId = V20NameHelper.FindOrdinaryAnimalId(arg, s_plainSpecialPrecursorFamilyIds);
                    if (precursorId != null) break;
                }
            }
            if (precursorId != null) generatorId = precursorId + "_family";
        }

        // V72.9：四種異常生物使用獨立精確 ID，不混入正常動物，也不把 Bioblob 誤併為 Tumor Monster。
        if (generatorId == null)
        {
            string anomalousId = V20NameHelper.FindOrdinaryAnimalId(__instance, s_plainAnomalousCreatureFamilyIds);
            if (anomalousId == null && __args != null)
            {
                foreach (object arg in __args)
                {
                    anomalousId = V20NameHelper.FindOrdinaryAnimalId(arg, s_plainAnomalousCreatureFamilyIds);
                    if (anomalousId != null) break;
                }
            }
            if (anomalousId != null) generatorId = anomalousId + "_family";
        }

        // V73：五種小型昆蟲使用獨立 plain ID。Dunglord 判斷位於上方，
        // 因此普通 beetle 使用 beetle_*；beetle + civ=true／civ_beetle 則仍使用 civ_beetle_*。
        if (generatorId == null)
        {
            string insectId = V20NameHelper.FindOrdinaryAnimalId(__instance, s_plainInsectFamilyIds);
            if (insectId == null && __args != null)
            {
                foreach (object arg in __args)
                {
                    insectId = V20NameHelper.FindOrdinaryAnimalId(arg, s_plainInsectFamilyIds);
                    if (insectId != null) break;
                }
            }
            if (insectId != null) generatorId = insectId + "_family";
        }

        // 三批普通動物仍維持既有 plain 路由；本版未改它們的資料。
        if (generatorId == null)
        {
            string ordinaryAnimalId = V20NameHelper.FindOrdinaryAnimalId(__instance, s_plainAnimalFamilyIds);
            if (ordinaryAnimalId == null && __args != null)
            {
                foreach (object arg in __args)
                {
                    ordinaryAnimalId = V20NameHelper.FindOrdinaryAnimalId(arg, s_plainAnimalFamilyIds);
                    if (ordinaryAnimalId != null) break;
                }
            }
            if (ordinaryAnimalId != null) generatorId = ordinaryAnimalId + "_family";
        }

        if (generatorId == null) return;

        var generator = CN_NameGeneratorLibrary.Instance.get(generatorId);
        if (generator == null) return;

        string newName = generator.GenerateName(new Dictionary<string, string>());
        if (string.IsNullOrWhiteSpace(newName)) return;

        V20NameHelper.SetName(__instance, newName);
    }
}
