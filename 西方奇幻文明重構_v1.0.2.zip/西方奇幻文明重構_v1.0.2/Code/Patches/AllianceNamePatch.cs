using System.Collections.Generic;
using Chinese_Name.utils;
using HarmonyLib;

namespace Chinese_Name;

public class AllianceNamePatch : IPatch
{
    public void Initialize()
    {
        new Harmony(nameof(set_alliance_name)).Patch(AccessTools.Method(typeof(WorldLog), nameof(WorldLog.logAllianceCreated)),
            prefix: new HarmonyMethod(typeof(AllianceNamePatch), nameof(set_alliance_name)));
        new Harmony(nameof(set_alliance_motto)).Patch(AccessTools.Method(typeof(Alliance), nameof(Alliance.getMotto)),
            prefix: new HarmonyMethod(AccessTools.Method(GetType(), nameof(set_alliance_motto))));
    }

    private static string GetAllianceGeneratorId(Alliance alliance)
    {
        if (alliance != null)
        {
            foreach (var kingdom in alliance.kingdoms_hashset)
            {
                string core_race = CoreRaceFramework.FromKingdom(kingdom);
                if (core_race != null) return CoreRaceFramework.GeneratorId(core_race, "alliance");
                if (V20NameHelper.IsBuffolon(kingdom)) return "civ_buffalo_alliance";
                if (V20NameHelper.IsArmaldar(kingdom)) return "civ_armadillo_alliance";
                if (V20NameHelper.IsPunkcorn(kingdom)) return "civ_unicorn_alliance";
                if (V20NameHelper.IsBaakin(kingdom)) return "civ_sheep_alliance";
                if (V20NameHelper.IsMootaur(kingdom)) return "civ_cow_alliance";
                if (V20NameHelper.IsSlypaw(kingdom)) return "civ_fox_alliance";
                if (V20NameHelper.IsPecklord(kingdom)) return "civ_chicken_alliance";
                if (V20NameHelper.IsBarkfolk(kingdom)) return "civ_dog_alliance";
                if (V20NameHelper.IsAcidGentleman(kingdom)) return "civ_acid_gentleman_alliance";
                if (V20NameHelper.IsGarlicMan(kingdom)) return "civ_garlic_man_alliance";
                if (V20NameHelper.IsLemonMan(kingdom)) return "civ_lemon_man_alliance";
                if (V20NameHelper.IsPlagueDoctor(kingdom)) return "civ_plague_doctor_alliance";
                if (V20NameHelper.IsDemon(kingdom)) return "civ_demon_alliance";
                if (V20NameHelper.IsFairy(kingdom)) return "civ_fairy_alliance";
                if (V20NameHelper.IsEvilMage(kingdom)) return "civ_evil_mage_alliance";
                if (V20NameHelper.IsAlien(kingdom)) return "civ_alien_alliance";
                if (V20NameHelper.IsWhiteMage(kingdom)) return "civ_white_mage_alliance";
                if (V20NameHelper.IsColdOne(kingdom)) return "civ_cold_one_alliance";
                if (V20NameHelper.IsAngle(kingdom)) return "civ_angle_alliance";
                if (V20NameHelper.IsSkeleton(kingdom)) return "civ_skeleton_alliance";
                if (V20NameHelper.IsSnowman(kingdom)) return "civ_snowman_alliance";
                if (V20NameHelper.IsDruid(kingdom)) return "civ_druid_alliance";
                if (V20NameHelper.IsGhost(kingdom)) return "civ_ghost_alliance";
                if (V20NameHelper.IsBandit(kingdom)) return "civ_bandit_alliance";
                if (V20NameHelper.IsJumpySkull(kingdom)) return "civ_jumpy_skull_alliance";
                if (V20NameHelper.IsFireSkull(kingdom)) return "civ_fire_skull_alliance";
                if (V20NameHelper.IsGreg(kingdom)) return "civ_greg_alliance";
                if (V20NameHelper.IsNecromancer(kingdom)) return "civ_necromancer_alliance";
                if (V20NameHelper.IsLulclaw(kingdom)) return "civ_hyena_alliance";
                if (V20NameHelper.IsNibling(kingdom)) return "civ_rat_alliance";
                if (V20NameHelper.IsCharmaca(kingdom)) return "civ_alpaca_alliance";
                if (V20NameHelper.IsHerdor(kingdom)) return "civ_goat_alliance";
                if (V20NameHelper.IsRibbit(kingdom)) return "civ_frog_alliance";
                if (V20NameHelper.IsGnapkin(kingdom)) return "civ_piranha_alliance";
                if (V20NameHelper.IsReptiloid(kingdom)) return "civ_crocodile_alliance";
                if (V20NameHelper.IsMeowmorph(kingdom)) return "civ_cat_alliance";
                if (V20NameHelper.IsDunglord(kingdom)) return "civ_beetle_alliance";
                if (V20NameHelper.IsArmococ(kingdom)) return "civ_armococ_alliance";
                if (V20NameHelper.IsGrranth(kingdom)) return "civ_grranth_alliance";
                if (V20NameHelper.IsCandyManCivilizationSource(kingdom)) return "civ_candy_alliance";
                if (V20NameHelper.IsCrab(kingdom)) return "civ_crab_alliance";
                if (V20NameHelper.IsTurtok(kingdom)) return "civ_turtle_alliance";
                if (V20NameHelper.IsNavySeal(kingdom)) return "civ_seal_alliance";
                if (V20NameHelper.IsMonkey(kingdom)) return "civ_monkey_alliance";
                if (V20NameHelper.IsHopper(kingdom)) return "civ_rabbit_alliance";
                if (V20NameHelper.IsScorp(kingdom)) return "civ_scorpion_alliance";
                if (V20NameHelper.IsCoolbeak(kingdom)) return "civ_coolbeak_alliance";
                if (V20NameHelper.IsLiliarCivilizationSource(kingdom)) return "civ_liliar_alliance";
                if (V20NameHelper.IsWolf(kingdom)) return "civ_wolf_alliance";
                if (V20NameHelper.IsSnake(kingdom)) return "civ_snake_alliance";
                if (V20NameHelper.IsCrystalCivilizationSource(kingdom)) return "civ_crystal_alliance";
                if (V20NameHelper.IsCapybara(kingdom)) return "civ_capybara_alliance";
            }
        }
        return "alliance_name";
    }

    private static bool set_alliance_motto(Alliance __instance)
    {
        if (!string.IsNullOrWhiteSpace(__instance.data.motto)) return true;
        string name_generator_id = GetAllianceGeneratorId(__instance);
        string motto_generator_id = name_generator_id.EndsWith("_alliance")
            ? name_generator_id.Substring(0, name_generator_id.Length - "_alliance".Length) + "_alliance_motto"
            : "alliance_mottos";
        var generator = CN_NameGeneratorLibrary.Instance.get(motto_generator_id)
                        ?? CN_NameGeneratorLibrary.Instance.get("alliance_mottos");
        if (generator == null) return true;
        var para = new Dictionary<string, string>();
        ParameterGetters.GetAllianceParameterGetter(generator.parameter_getter)(__instance, para);
        __instance.data.motto = generator.GenerateName(para);
        return true;
    }

    private static void set_alliance_name(Alliance pAlliance)
    {
        var generator = CN_NameGeneratorLibrary.Instance.get(GetAllianceGeneratorId(pAlliance)) ?? CN_NameGeneratorLibrary.Instance.get("alliance_name");
        if (generator == null) return;
        var para = new Dictionary<string, string>();
        ParameterGetters.GetAllianceParameterGetter(generator.parameter_getter)(pAlliance, para);
        pAlliance.data.name = generator.GenerateName(para);
    }
}
