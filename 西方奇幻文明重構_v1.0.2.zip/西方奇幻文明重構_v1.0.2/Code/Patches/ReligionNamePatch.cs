using System.Collections.Generic;
using Chinese_Name.utils;
using HarmonyLib;

namespace Chinese_Name;

public class ReligionNamePatch : IPatch
{
    public void Initialize()
    {
        new Harmony(nameof(set_religion_name)).Patch(AccessTools.Method(typeof(Religion), nameof(Religion.generateName)),
            postfix: new HarmonyMethod(GetType(), nameof(set_religion_name)));
    }
    private static void set_religion_name(Religion __instance, Actor pActor)
    {
        string race_id = pActor.asset.id;
        string template_id;
        string core_race = CoreRaceFramework.FromActor(pActor);
        if (core_race != null) template_id = CoreRaceFramework.GeneratorId(core_race, "religion");
        else if (V20NameHelper.IsBuffolon(pActor)) template_id = "civ_buffalo_religion";
        else if (V20NameHelper.IsArmaldar(pActor)) template_id = "civ_armadillo_religion";
        else if (V20NameHelper.IsPunkcorn(pActor)) template_id = "civ_unicorn_religion";
        else if (V20NameHelper.IsBaakin(pActor)) template_id = "civ_sheep_religion";
        else if (V20NameHelper.IsMootaur(pActor)) template_id = "civ_cow_religion";
        else if (V20NameHelper.IsSlypaw(pActor)) template_id = "civ_fox_religion";
        else if (V20NameHelper.IsPecklord(pActor)) template_id = "civ_chicken_religion";
        else if (V20NameHelper.IsBarkfolk(pActor)) template_id = "civ_dog_religion";
        else if (V20NameHelper.IsAcidGentleman(pActor)) template_id = "civ_acid_gentleman_religion";
        else if (V20NameHelper.IsGarlicMan(pActor)) template_id = "civ_garlic_man_religion";
        else if (V20NameHelper.IsLemonMan(pActor)) template_id = "civ_lemon_man_religion";
        else if (V20NameHelper.IsPlagueDoctor(pActor)) template_id = "civ_plague_doctor_religion";
        else if (V20NameHelper.IsDemon(pActor)) template_id = "civ_demon_religion";
        else if (V20NameHelper.IsFairy(pActor)) template_id = "civ_fairy_religion";
        else if (V20NameHelper.IsEvilMage(pActor)) template_id = "civ_evil_mage_religion";
        else if (V20NameHelper.IsAlien(pActor)) template_id = "civ_alien_religion";
        else if (V20NameHelper.IsWhiteMage(pActor)) template_id = "civ_white_mage_religion";
        else if (V20NameHelper.IsColdOne(pActor)) template_id = "civ_cold_one_religion";
        else if (V20NameHelper.IsAngle(pActor)) template_id = "civ_angle_religion";
        else if (V20NameHelper.IsSkeleton(pActor)) template_id = "civ_skeleton_religion";
        else if (V20NameHelper.IsSnowman(pActor)) template_id = "civ_snowman_religion";
        else if (V20NameHelper.IsDruid(pActor)) template_id = "civ_druid_religion";
        else if (V20NameHelper.IsGhost(pActor)) template_id = "civ_ghost_religion";
        else if (V20NameHelper.IsBandit(pActor)) template_id = "civ_bandit_religion";
        else if (V20NameHelper.IsJumpySkull(pActor)) template_id = "civ_jumpy_skull_religion";
        else if (V20NameHelper.IsFireSkull(pActor)) template_id = "civ_fire_skull_religion";
        else if (V20NameHelper.IsGreg(pActor)) template_id = "civ_greg_religion";
        else if (V20NameHelper.IsNecromancer(pActor)) template_id = "civ_necromancer_religion";
        else if (V20NameHelper.IsLulclaw(pActor)) template_id = "civ_hyena_religion";
        else if (V20NameHelper.IsNibling(pActor)) template_id = "civ_rat_religion";
        else if (V20NameHelper.IsCharmaca(pActor)) template_id = "civ_alpaca_religion";
        else if (V20NameHelper.IsHerdor(pActor)) template_id = "civ_goat_religion";
        else if (V20NameHelper.IsRibbit(pActor)) template_id = "civ_frog_religion";
        else if (V20NameHelper.IsGnapkin(pActor)) template_id = "civ_piranha_religion";
        else if (V20NameHelper.IsReptiloid(pActor)) template_id = "civ_crocodile_religion";
        else if (V20NameHelper.IsMeowmorph(pActor)) template_id = "civ_cat_religion";
        else if (V20NameHelper.IsDunglord(pActor)) template_id = "civ_beetle_religion";
        else if (V20NameHelper.IsArmococ(pActor)) template_id = "civ_armococ_religion";
        else if (V20NameHelper.IsGrranth(pActor)) template_id = "civ_grranth_religion";
        else if (V20NameHelper.IsCandyManCivilizationSource(pActor)) template_id = "civ_candy_religion";
        else if (V20NameHelper.IsCrab(pActor)) template_id = "civ_crab_religion";
        else if (V20NameHelper.IsTurtok(pActor)) template_id = "civ_turtle_religion";
        else if (V20NameHelper.IsNavySeal(pActor)) template_id = "civ_seal_religion";
        else if (V20NameHelper.IsMonkey(pActor)) template_id = "civ_monkey_religion";
        else if (V20NameHelper.IsHopper(pActor)) template_id = "civ_hopper_religion";
        else if (V20NameHelper.IsScorp(pActor)) template_id = "civ_scorpion_religion";
        else if (V20NameHelper.IsCoolbeak(pActor)) template_id = "civ_coolbeak_religion";
        else if (V20NameHelper.IsLiliarCivilizationSource(pActor)) template_id = "civ_liliar_religion";
        else if (V20NameHelper.IsWolf(pActor)) template_id = "civ_wolf_religion";
        else if (V20NameHelper.IsSnake(pActor)) template_id = "civ_snake_religion";
        else if (V20NameHelper.IsCrystalCivilizationSource(pActor)) template_id = "civ_crystal_religion";
        else if (V20NameHelper.IsCapybara(pActor)) template_id = "civ_capybara_religion";
        else template_id = $"{race_id}_religion";
        // 按种族取宗教模板，缺省回退到修仙默认
        if (CN_NameGeneratorLibrary.Instance.get(template_id) == null)
        {
            template_id = "default_religion";
        }
        var generator = CN_NameGeneratorLibrary.Instance.get(template_id);
        if (generator == null) return;

        var para = new Dictionary<string, string>();

        ParameterGetters.GetReligionParameterGetter(generator.parameter_getter)(__instance, para);

        __instance.data.name = generator.GenerateName(para);
    }
}
