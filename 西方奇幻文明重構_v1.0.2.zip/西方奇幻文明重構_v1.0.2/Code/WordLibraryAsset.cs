﻿using System;
using System.Collections.Generic;

namespace Chinese_Name;

public class WordLibraryAsset : Asset
{
    public readonly List<string> words;
    internal WordLibraryAsset(string id, List<string> words)
    {
        this.id = id;
        this.words = words;
        this.words ??= new List<string>();
    }
    public string GetRandom()
    {
        if (words == null || words.Count == 0) return string.Empty;
        int index = NameRandom.NextIndex(words.Count);
        return index >= 0 ? words[index] : string.Empty;
    }
}