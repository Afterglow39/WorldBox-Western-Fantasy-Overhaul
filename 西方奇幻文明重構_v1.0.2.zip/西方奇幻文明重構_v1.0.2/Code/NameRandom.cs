﻿using System;

namespace Chinese_Name;

/// <summary>
/// 西方奇幻文明重構專用命名亂數。
/// 與 UnityEngine.Random 完全隔離，避免 WorldBox 切換／重建世界時
/// 重設遊戲亂數狀態，導致每張新地圖的第一、第二個名稱固定重複。
/// </summary>
internal static class NameRandom
{
    private static readonly object SyncRoot = new();
    private static readonly Random Generator = CreateGenerator();

    private static Random CreateGenerator()
    {
        unchecked
        {
            int seed = Environment.TickCount;
            seed = (seed * 397) ^ Guid.NewGuid().GetHashCode();
            seed = (seed * 397) ^ (int)DateTime.UtcNow.Ticks;
            return new Random(seed);
        }
    }

    public static float NextFloat(float maxExclusive)
    {
        if (maxExclusive <= 0f) return 0f;
        lock (SyncRoot)
        {
            return (float)(Generator.NextDouble() * maxExclusive);
        }
    }

    public static int NextIndex(int count)
    {
        if (count <= 0) return -1;
        lock (SyncRoot)
        {
            return Generator.Next(count);
        }
    }
}
