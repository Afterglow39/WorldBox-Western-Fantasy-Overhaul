using System;
using System.Reflection;

namespace Chinese_Name;

/// <summary>
/// V71.6 四大主文明單一資料源路由。
/// 只辨識 Human / Elf / Dwarf / Orc 的直接種族證據；不做跨物件遞迴，不碰其他文明判定。
/// </summary>
internal static class CoreRaceFramework
{
    internal const string Human = "human";
    internal const string Elf = "elf";
    internal const string Dwarf = "dwarf";
    internal const string Orc = "orc";

    internal static string FromId(string value)
    {
        string id = Normalize(value);
        switch (id)
        {
            case "human":
            case "civ_human":
                return Human;
            case "elf":
            case "civ_elf":
                return Elf;
            case "dwarf":
            case "civ_dwarf":
                return Dwarf;
            case "orc":
            case "civ_orc":
                return Orc;
            default:
                return null;
        }
    }

    internal static string FromActor(Actor actor)
    {
        return actor == null || actor.asset == null ? null : FromId(actor.asset.id);
    }

    internal static string FromKingdom(Kingdom kingdom)
    {
        return kingdom == null || kingdom.data == null ? null : FromId(kingdom.data.original_actor_asset);
    }

    internal static string FromCity(City city)
    {
        return city == null || city.data == null ? null : FromId(city.data.original_actor_asset);
    }

    internal static string FromCulture(Culture culture)
    {
        return culture == null || culture.data == null ? null : FromId(culture.data.original_actor_asset);
    }

    internal static string FromClan(Clan clan)
    {
        return clan == null || clan.data == null ? null : FromId(clan.data.original_actor_asset);
    }

    internal static string FromSubspecies(Subspecies subspecies)
    {
        return subspecies == null ? null : FromId(subspecies.species_id);
    }

    internal static string FromArguments(object[] args)
    {
        if (args == null) return null;
        foreach (object arg in args)
        {
            string race = FromDirectObject(arg);
            if (race != null) return race;
        }
        return null;
    }

    internal static string FromDirectObject(object source)
    {
        return FromDirectObject(source, true);
    }

    private static string FromDirectObject(object source, bool allowAnchors)
    {
        if (source == null) return null;
        if (source is string text) return FromId(text);
        if (source is Actor actor) return FromActor(actor);
        if (source is Kingdom kingdom) return FromKingdom(kingdom);
        if (source is City city) return FromCity(city);
        if (source is Culture culture) return FromCulture(culture);
        if (source is Clan clan) return FromClan(clan);
        if (source is Subspecies subspecies) return FromSubspecies(subspecies);

        string race = FromId(ReadString(source, "species_id"));
        if (race != null) return race;
        race = FromId(ReadString(source, "race_id"));
        if (race != null) return race;
        race = FromId(ReadString(source, "original_actor_asset"));
        if (race != null) return race;
        race = FromId(ReadString(source, "originalActorAsset"));
        if (race != null) return race;
        race = FromId(ReadString(source, "actor_asset"));
        if (race != null) return race;

        object asset = Read(source, "asset");
        race = FromId(ReadString(asset, "id"));
        if (race != null) return race;

        object data = Read(source, "data");
        race = FromId(ReadString(data, "original_actor_asset"));
        if (race != null) return race;
        race = FromId(ReadString(data, "originalActorAsset"));
        if (race != null) return race;
        race = FromId(ReadString(data, "species_id"));
        if (race != null) return race;

        // 家庭類別的建立方法版本不一；只讀取它自己直接持有的建立者／家長參照。
        // 不再向王國、城市、成員集合或其他文明物件遞迴搜尋。
        if (allowAnchors)
        {
            string[] anchors = { "founder", "founder_actor", "head", "leader", "actor", "unit", "parent", "parent1", "parent2" };
            foreach (string anchor in anchors)
            {
                object value = Read(source, anchor);
                race = FromDirectObject(value, false);
                if (race != null) return race;
            }
        }

        return null;
    }

    internal static string GeneratorId(string race, string category)
    {
        return race == null || string.IsNullOrWhiteSpace(category) ? null : $"civ_{race}_{category}";
    }

    internal static string BookGeneratorId(string race, string baseTemplateId)
    {
        return race == null || string.IsNullOrWhiteSpace(baseTemplateId) ? baseTemplateId : $"civ_{race}_{baseTemplateId}";
    }

    private static string Normalize(string value)
    {
        return string.IsNullOrWhiteSpace(value)
            ? ""
            : value.Trim().ToLowerInvariant().Replace(" ", "_").Replace("-", "_");
    }

    private static string ReadString(object source, string member)
    {
        return Read(source, member) as string;
    }

    private static object Read(object source, string member)
    {
        if (source == null) return null;
        Type type = source.GetType();
        const BindingFlags flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.IgnoreCase;
        try
        {
            PropertyInfo property = type.GetProperty(member, flags);
            if (property != null && property.GetIndexParameters().Length == 0)
                return property.GetValue(source, null);
            FieldInfo field = type.GetField(member, flags);
            if (field != null) return field.GetValue(source);
        }
        catch { }
        return null;
    }
}
