using System.Collections.Generic;
using Chinese_Name.utils;
using HarmonyLib;

namespace Chinese_Name;

public class LanguageNamePatch : IPatch
{
    public void Initialize()
    {
        new Harmony(nameof(set_lang_name)).Patch(AccessTools.Method(typeof(Language), nameof(Language.generateName)),
            postfix: new HarmonyMethod(GetType(), nameof(set_lang_name)));
    }
    private static void set_lang_name(Language __instance, Actor pActor)
    {
        string race_id = pActor.asset.id;
        string template_id;
        string core_race = CoreRaceFramework.FromActor(pActor);
        if (core_race != null) template_id = CoreRaceFramework.GeneratorId(core_race, "lang");
        else if (V20NameHelper.IsBuffolon(pActor)) template_id = "civ_buffalo_lang";
        else if (V20NameHelper.IsArmaldar(pActor)) template_id = "civ_armadillo_lang";
        else if (V20NameHelper.IsPunkcorn(pActor)) template_id = "civ_unicorn_lang";
        else if (V20NameHelper.IsBaakin(pActor)) template_id = "civ_sheep_lang";
        else if (V20NameHelper.IsMootaur(pActor)) template_id = "civ_cow_lang";
        else if (V20NameHelper.IsSlypaw(pActor)) template_id = "civ_fox_lang";
        else if (V20NameHelper.IsPecklord(pActor)) template_id = "civ_chicken_lang";
        else if (V20NameHelper.IsBarkfolk(pActor)) template_id = "civ_dog_lang";
        else if (V20NameHelper.IsAcidGentleman(pActor)) template_id = "civ_acid_gentleman_lang";
        else if (V20NameHelper.IsGarlicMan(pActor)) template_id = "civ_garlic_man_lang";
        else if (V20NameHelper.IsLemonMan(pActor)) template_id = "civ_lemon_man_lang";
        else if (V20NameHelper.IsPlagueDoctor(pActor)) template_id = "civ_plague_doctor_lang";
        else if (V20NameHelper.IsDemon(pActor)) template_id = "civ_demon_lang";
        else if (V20NameHelper.IsFairy(pActor)) template_id = "civ_fairy_lang";
        else if (V20NameHelper.IsEvilMage(pActor)) template_id = "civ_evil_mage_lang";
        else if (V20NameHelper.IsAlien(pActor)) template_id = "civ_alien_lang";
        else if (V20NameHelper.IsWhiteMage(pActor)) template_id = "civ_white_mage_lang";
        else if (V20NameHelper.IsColdOne(pActor)) template_id = "civ_cold_one_lang";
        else if (V20NameHelper.IsAngle(pActor)) template_id = "civ_angle_lang";
        else if (V20NameHelper.IsSkeleton(pActor)) template_id = "civ_skeleton_lang";
        else if (V20NameHelper.IsSnowman(pActor)) template_id = "civ_snowman_lang";
        else if (V20NameHelper.IsDruid(pActor)) template_id = "civ_druid_lang";
        else if (V20NameHelper.IsGhost(pActor)) template_id = "civ_ghost_lang";
        else if (V20NameHelper.IsBandit(pActor)) template_id = "civ_bandit_lang";
        else if (V20NameHelper.IsJumpySkull(pActor)) template_id = "civ_jumpy_skull_lang";
        else if (V20NameHelper.IsFireSkull(pActor)) template_id = "civ_fire_skull_lang";
        else if (V20NameHelper.IsGreg(pActor)) template_id = "civ_greg_lang";
        else if (V20NameHelper.IsNecromancer(pActor)) template_id = "civ_necromancer_lang";
        else if (V20NameHelper.IsLulclaw(pActor)) template_id = "civ_hyena_lang";
        else if (V20NameHelper.IsNibling(pActor)) template_id = "civ_rat_lang";
        else if (V20NameHelper.IsCharmaca(pActor)) template_id = "civ_alpaca_lang";
        else if (V20NameHelper.IsHerdor(pActor)) template_id = "civ_goat_lang";
        else if (V20NameHelper.IsRibbit(pActor)) template_id = "civ_frog_lang";
        else if (V20NameHelper.IsGnapkin(pActor)) template_id = "civ_piranha_lang";
        else if (V20NameHelper.IsReptiloid(pActor)) template_id = "civ_crocodile_lang";
        else if (V20NameHelper.IsMeowmorph(pActor)) template_id = "civ_cat_lang";
        else if (V105FallbackFramework.IsSmallCreature(pActor)) template_id = V105FallbackFramework.SmallGenerator("lang");
        else if (V20NameHelper.IsDunglord(pActor)) template_id = "civ_beetle_lang";
        else if (V20NameHelper.IsArmococ(pActor)) template_id = "civ_armococ_lang";
        else if (V20NameHelper.IsGrranth(pActor)) template_id = "civ_grranth_lang";
        else if (V20NameHelper.IsCandyManCivilizationSource(pActor)) template_id = "civ_candy_lang";
        else if (V20NameHelper.IsCrab(pActor)) template_id = "civ_crab_lang";
        else if (V20NameHelper.IsTurtok(pActor)) template_id = "civ_turtle_lang";
        else if (V20NameHelper.IsNavySeal(pActor)) template_id = "civ_seal_lang";
        else if (V20NameHelper.IsMonkey(pActor)) template_id = "civ_monkey_lang";
        else if (V20NameHelper.IsHopper(pActor)) template_id = "civ_hopper_lang";
        else if (V20NameHelper.IsScorp(pActor)) template_id = "civ_scorpion_lang";
        else if (V20NameHelper.IsCoolbeak(pActor)) template_id = "civ_coolbeak_lang";
        else if (V20NameHelper.IsLiliarCivilizationSource(pActor)) template_id = "civ_liliar_lang";
        else if (V20NameHelper.IsWolf(pActor)) template_id = "civ_wolf_lang";
        else if (V20NameHelper.IsSnake(pActor)) template_id = "civ_snake_lang";
        else if (V20NameHelper.IsCrystalCivilizationSource(pActor)) template_id = "civ_crystal_lang";
        else if (V20NameHelper.IsCapybara(pActor)) template_id = "civ_capybara_lang";
        else template_id = V105FallbackFramework.UnknownGenerator("lang");
        // V1.0.5：專屬／小型生物模板缺失時，也只回退本模組的未知文明語言。
        if (CN_NameGeneratorLibrary.Instance.get(template_id) == null)
        {
            template_id = V105FallbackFramework.UnknownGenerator("lang");
        }
        var generator = CN_NameGeneratorLibrary.Instance.get(template_id);
        if (generator == null) return;

        var para = new Dictionary<string, string>();

        ParameterGetters.GetLanguageParameterGetter(generator.parameter_getter)(__instance, para);

        __instance.data.name = generator.GenerateName(para);
    }
}
