using System.Collections.Generic;
using Chinese_Name.utils;
using HarmonyLib;

namespace Chinese_Name;

public class BookNamePatch : IPatch
{
    public void Initialize()
    {
        new Harmony(nameof(set_book_name)).Patch(AccessTools.Method(typeof(Book), nameof(Book.newBook)),
            postfix: new HarmonyMethod(GetType(), nameof(set_book_name)));
    }

    /// <summary>
    /// V28.4：書籍建立完成後，優先從 Book.newBook 的實際參數辨識作者／建立者文明。
    /// 舊版只檢查 Book 本體；但作者文明通常仍在 newBook 的參數中，尚未保存到 Book 可遞迴取得的欄位。
    /// </summary>
    private static void set_book_name(Book __instance, BookTypeAsset pBookType, object[] __args)
    {
        if (__instance == null || pBookType == null || string.IsNullOrWhiteSpace(pBookType.name_template)) return;

        string base_template_id = pBookType.name_template;
        string template_id = ResolveCivilizationTemplate(base_template_id, __args, __instance);

        // 若文明專屬 Generator 不存在，才退回原版通用書名。
        var generator = CN_NameGeneratorLibrary.Instance.get(template_id);
        if (generator == null && template_id != base_template_id)
        {
            generator = CN_NameGeneratorLibrary.Instance.get(base_template_id);
        }
        if (generator == null) return;

        var para = new Dictionary<string, string>();
        ParameterGetters.GetBookParameterGetter(generator.parameter_getter)(__instance, para);

        var generated_name = generator.GenerateName(para);
        if (string.IsNullOrWhiteSpace(generated_name)) return;
        V20NameHelper.SetName(__instance, generated_name);
    }

    private static string ResolveCivilizationTemplate(string pBaseTemplateId, object[] pArgs, Book pBook)
    {
        // 先讀取 newBook 的所有真實參數。作者 Actor、城市或王國若在參數中，這裡可直接辨識。
        if (pArgs != null)
        {
            foreach (object arg in pArgs)
            {
                string routed = RouteByObject(pBaseTemplateId, arg);
                if (!string.IsNullOrWhiteSpace(routed)) return routed;
            }
        }

        // 保留 Book 本體作為次要路徑，兼容遊戲未來把作者資料存入 Book 的情況。
        string bookRoute = RouteByObject(pBaseTemplateId, pBook);
        if (!string.IsNullOrWhiteSpace(bookRoute)) return bookRoute;

        // 所有參數與 Book 本體都未命中既有文明時，才進入真正的「其餘物種」全套保底。
        return V105FallbackFramework.UnknownGenerator(pBaseTemplateId);
    }

    private static string RouteByObject(string pBaseTemplateId, object pSource)
    {
        if (pSource == null) return null;
        string core_race = CoreRaceFramework.FromDirectObject(pSource);
        if (core_race != null) return CoreRaceFramework.BookGeneratorId(core_race, pBaseTemplateId);
        if (V20NameHelper.IsBuffolon(pSource)) return $"civ_buffalo_{pBaseTemplateId}";
        if (V20NameHelper.IsArmaldar(pSource)) return $"civ_armadillo_{pBaseTemplateId}";
        if (V20NameHelper.IsPunkcorn(pSource)) return $"civ_unicorn_{pBaseTemplateId}";
        if (V20NameHelper.IsBaakin(pSource)) return $"civ_sheep_{pBaseTemplateId}";
        if (V20NameHelper.IsMootaur(pSource)) return $"civ_cow_{pBaseTemplateId}";
        if (V20NameHelper.IsSlypaw(pSource)) return $"civ_fox_{pBaseTemplateId}";
        if (V20NameHelper.IsPecklord(pSource)) return $"civ_chicken_{pBaseTemplateId}";
        if (V20NameHelper.IsBarkfolk(pSource)) return $"civ_dog_{pBaseTemplateId}";
        if (V20NameHelper.IsAcidGentleman(pSource)) return $"civ_acid_gentleman_{pBaseTemplateId}";
        if (V20NameHelper.IsGarlicMan(pSource)) return $"civ_garlic_man_{pBaseTemplateId}";
        if (V20NameHelper.IsLemonMan(pSource)) return $"civ_lemon_man_{pBaseTemplateId}";
        if (V20NameHelper.IsPlagueDoctor(pSource)) return $"civ_plague_doctor_{pBaseTemplateId}";
        if (V20NameHelper.IsDemon(pSource)) return $"civ_demon_{pBaseTemplateId}";
        if (V20NameHelper.IsFairy(pSource)) return $"civ_fairy_{pBaseTemplateId}";
        if (V20NameHelper.IsEvilMage(pSource)) return $"civ_evil_mage_{pBaseTemplateId}";
        if (V20NameHelper.IsAlien(pSource)) return $"civ_alien_{pBaseTemplateId}";
        if (V20NameHelper.IsWhiteMage(pSource)) return $"civ_white_mage_{pBaseTemplateId}";
        if (V20NameHelper.IsColdOne(pSource)) return $"civ_cold_one_{pBaseTemplateId}";
        if (V20NameHelper.IsAngle(pSource)) return $"civ_angle_{pBaseTemplateId}";
        if (V20NameHelper.IsSkeleton(pSource)) return $"civ_skeleton_{pBaseTemplateId}";
        if (V20NameHelper.IsSnowman(pSource)) return $"civ_snowman_{pBaseTemplateId}";
        if (V20NameHelper.IsDruid(pSource)) return $"civ_druid_{pBaseTemplateId}";
        if (V20NameHelper.IsGhost(pSource)) return $"civ_ghost_{pBaseTemplateId}";
        if (V20NameHelper.IsBandit(pSource)) return $"civ_bandit_{pBaseTemplateId}";
        if (V20NameHelper.IsJumpySkull(pSource)) return $"civ_jumpy_skull_{pBaseTemplateId}";
        if (V20NameHelper.IsFireSkull(pSource)) return $"civ_fire_skull_{pBaseTemplateId}";
        if (V20NameHelper.IsGreg(pSource)) return $"civ_greg_{pBaseTemplateId}";
        if (V20NameHelper.IsNecromancer(pSource)) return $"civ_necromancer_{pBaseTemplateId}";
        if (V20NameHelper.IsLulclaw(pSource)) return $"civ_hyena_{pBaseTemplateId}";
        if (V20NameHelper.IsNibling(pSource)) return $"civ_rat_{pBaseTemplateId}";
        if (V20NameHelper.IsCharmaca(pSource)) return $"civ_alpaca_{pBaseTemplateId}";
        if (V20NameHelper.IsHerdor(pSource)) return $"civ_goat_{pBaseTemplateId}";
        if (V20NameHelper.IsRibbit(pSource)) return $"civ_frog_{pBaseTemplateId}";
        if (V20NameHelper.IsGnapkin(pSource)) return $"civ_piranha_{pBaseTemplateId}";
        if (V20NameHelper.IsReptiloid(pSource)) return $"civ_crocodile_{pBaseTemplateId}";
        if (V20NameHelper.IsMeowmorph(pSource)) return $"civ_cat_{pBaseTemplateId}";
        if (V105FallbackFramework.IsSmallCreature(pSource)) return V105FallbackFramework.SmallGenerator(pBaseTemplateId);
        if (V20NameHelper.IsDunglord(pSource)) return $"civ_beetle_{pBaseTemplateId}";
        if (V20NameHelper.IsArmococ(pSource)) return $"civ_armococ_{pBaseTemplateId}";
        if (V20NameHelper.IsGrranth(pSource)) return $"civ_grranth_{pBaseTemplateId}";
        if (V20NameHelper.IsCandyManCivilizationSource(pSource)) return $"civ_candy_{pBaseTemplateId}";
        if (V20NameHelper.IsCrab(pSource)) return $"civ_crab_{pBaseTemplateId}";
        if (V20NameHelper.IsTurtok(pSource)) return $"civ_turtle_{pBaseTemplateId}";
        if (V20NameHelper.IsNavySeal(pSource)) return $"civ_seal_{pBaseTemplateId}";
        if (V20NameHelper.IsMonkey(pSource)) return $"civ_monkey_{pBaseTemplateId}";
        if (V20NameHelper.IsHopper(pSource)) return $"civ_hopper_{pBaseTemplateId}";
        if (V20NameHelper.IsScorp(pSource)) return $"civ_scorpion_{pBaseTemplateId}";
        if (V20NameHelper.IsCoolbeak(pSource)) return $"civ_coolbeak_{pBaseTemplateId}";
        if (V20NameHelper.IsLiliarCivilizationSource(pSource)) return $"civ_liliar_{pBaseTemplateId}";
        if (V20NameHelper.IsWolf(pSource)) return $"civ_wolf_{pBaseTemplateId}";
        if (V20NameHelper.IsSnake(pSource)) return $"civ_snake_{pBaseTemplateId}";
        if (V20NameHelper.IsCrystalCivilizationSource(pSource)) return $"civ_crystal_{pBaseTemplateId}";
        if (V20NameHelper.IsCapybara(pSource)) return $"civ_capybara_{pBaseTemplateId}";
        return null;
    }
}
