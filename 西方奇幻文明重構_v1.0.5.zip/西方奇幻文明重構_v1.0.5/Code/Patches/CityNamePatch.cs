using System.Collections.Generic;
using Chinese_Name.utils;
using HarmonyLib;
using NeoModLoader.api.attributes;
using NeoModLoader.General.Event.Handlers;
using NeoModLoader.General.Event.Listeners;

namespace Chinese_Name;

public class CityNamePatch : IPatch
{
    public void Initialize()
    {
        new Harmony(nameof(set_city_name)).Patch(AccessTools.Method(typeof(City), nameof(City.generateName)),
            postfix: new HarmonyMethod(typeof(CityNamePatch), nameof(set_city_name)));
    }
    [Hotfixable]
    private static void set_city_name(City __instance, Actor pActor)
    {
        string race_id = pActor.asset.id;
        string template_id;
        string core_race = CoreRaceFramework.FromActor(pActor);
        if (core_race != null) template_id = CoreRaceFramework.GeneratorId(core_race, "city");
        else if (V20NameHelper.IsBuffolon(pActor)) template_id = "civ_buffalo_city";
        else if (V20NameHelper.IsArmaldar(pActor)) template_id = "civ_armadillo_city";
        else if (V20NameHelper.IsPunkcorn(pActor)) template_id = "civ_unicorn_city";
        else if (V20NameHelper.IsBaakin(pActor)) template_id = "civ_sheep_city";
        else if (V20NameHelper.IsMootaur(pActor)) template_id = "civ_cow_city";
        else if (V20NameHelper.IsSlypaw(pActor)) template_id = "civ_fox_city";
        else if (V20NameHelper.IsPecklord(pActor)) template_id = "civ_chicken_city";
        else if (V20NameHelper.IsBarkfolk(pActor)) template_id = "civ_dog_city";
        else if (V20NameHelper.IsAcidGentleman(pActor)) template_id = "civ_acid_gentleman_city";
        else if (V20NameHelper.IsGarlicMan(pActor)) template_id = "civ_garlic_man_city";
        else if (V20NameHelper.IsLemonMan(pActor)) template_id = "civ_lemon_man_city";
        else if (V20NameHelper.IsPlagueDoctor(pActor)) template_id = "civ_plague_doctor_city";
        else if (V20NameHelper.IsDemon(pActor)) template_id = "civ_demon_city";
        else if (V20NameHelper.IsFairy(pActor)) template_id = "civ_fairy_city";
        else if (V20NameHelper.IsEvilMage(pActor)) template_id = "civ_evil_mage_city";
        else if (V20NameHelper.IsAlien(pActor)) template_id = "civ_alien_city";
        else if (V20NameHelper.IsWhiteMage(pActor)) template_id = "civ_white_mage_city";
        else if (V20NameHelper.IsColdOne(pActor)) template_id = "civ_cold_one_city";
        else if (V20NameHelper.IsAngle(pActor)) template_id = "civ_angle_city";
        else if (V20NameHelper.IsSkeleton(pActor)) template_id = "civ_skeleton_city";
        else if (V20NameHelper.IsSnowman(pActor)) template_id = "civ_snowman_city";
        else if (V20NameHelper.IsDruid(pActor)) template_id = "civ_druid_city";
        else if (V20NameHelper.IsGhost(pActor)) template_id = "civ_ghost_city";
        else if (V20NameHelper.IsBandit(pActor)) template_id = "civ_bandit_city";
        else if (V20NameHelper.IsJumpySkull(pActor)) template_id = "civ_jumpy_skull_city";
        else if (V20NameHelper.IsFireSkull(pActor)) template_id = "civ_fire_skull_city";
        else if (V20NameHelper.IsGreg(pActor)) template_id = "civ_greg_city";
        else if (V20NameHelper.IsNecromancer(pActor)) template_id = "civ_necromancer_city";
        else if (V20NameHelper.IsLulclaw(pActor)) template_id = "civ_hyena_city";
        else if (V20NameHelper.IsNibling(pActor)) template_id = "civ_rat_city";
        else if (V20NameHelper.IsCharmaca(pActor)) template_id = "civ_alpaca_city";
        else if (V20NameHelper.IsHerdor(pActor)) template_id = "civ_goat_city";
        else if (V20NameHelper.IsRibbit(pActor)) template_id = "civ_frog_city";
        else if (V20NameHelper.IsGnapkin(pActor)) template_id = "civ_piranha_city";
        else if (V20NameHelper.IsReptiloid(pActor)) template_id = "civ_crocodile_city";
        else if (V20NameHelper.IsMeowmorph(pActor)) template_id = "civ_cat_city";
        else if (V105FallbackFramework.IsSmallCreature(pActor)) template_id = V105FallbackFramework.SmallGenerator("city");
        else if (V20NameHelper.IsDunglord(pActor)) template_id = "civ_beetle_city";
        else if (V20NameHelper.IsArmococ(pActor)) template_id = "civ_armococ_city";
        else if (V20NameHelper.IsGrranth(pActor)) template_id = "civ_grranth_city";
        else if (V20NameHelper.IsCandyManCivilizationSource(pActor)) template_id = "civ_candy_city";
        else if (V20NameHelper.IsCrab(pActor)) template_id = "civ_crab_city";
        else if (V20NameHelper.IsTurtok(pActor)) template_id = "civ_turtle_city";
        else if (V20NameHelper.IsNavySeal(pActor)) template_id = "civ_seal_city";
        else if (V20NameHelper.IsMonkey(pActor)) template_id = "civ_monkey_city";
        else if (V20NameHelper.IsHopper(pActor)) template_id = "civ_hopper_city";
        else if (V20NameHelper.IsScorp(pActor)) template_id = "civ_scorpion_city";
        else if (V20NameHelper.IsCoolbeak(pActor)) template_id = "civ_coolbeak_city";
        else if (V20NameHelper.IsLiliarCivilizationSource(pActor)) template_id = "civ_liliar_city";
        else if (V20NameHelper.IsWolf(pActor)) template_id = "civ_wolf_city";
        else if (V20NameHelper.IsSnake(pActor)) template_id = "civ_snake_city";
        else if (V20NameHelper.IsCrystalCivilizationSource(pActor)) template_id = "civ_crystal_city";
        else if (V20NameHelper.IsCapybara(pActor)) template_id = "civ_capybara_city";
        else template_id = V105FallbackFramework.UnknownGenerator("city");
        var generator = CN_NameGeneratorLibrary.Instance.get(template_id);
        if (generator == null) return;

var para = new Dictionary<string, string>();

        ParameterGetters.GetCityParameterGetter(generator.parameter_getter)(__instance, para);

        __instance.data.name = generator.GenerateName(para);
    }
}
