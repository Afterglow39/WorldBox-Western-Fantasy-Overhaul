using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;

namespace Chinese_Name;

/// <summary>
/// V1.0.5 兩層保底框架：
/// 1. 已知小型生物文明（鴕鳥、蜜蜂、蝴蝶、蚱蜢、蒼蠅、甲蟲）共用 civ_smallfolk_* 社會資料。
/// 2. 其餘所有未命中既有專屬文明的來源，統一使用 civ_unknown_*，不再回到舊版零散資料。
/// 人物名稱、家庭與亞種仍由各物種自己的既有模板優先處理。
/// </summary>
internal static class V105FallbackFramework
{
    private static readonly HashSet<string> s_smallAliases = new(StringComparer.OrdinalIgnoreCase)
    {
        "ostrich",
        "bee",
        "butterfly",
        "grasshopper",
        "fly",
        "beetle",
        "dung_beetle",
        "dungbeetle",
        "dunglord",
        "dung_lord"
    };

    // 已知已完成的普通／前身／特殊生物。Actor 名稱只有命中這份白名單時，
    // 才允許繼續使用 <id>_name；其餘未辨識來源直接進入 civ_unknown_name。
    private static readonly HashSet<string> s_curatedPlainActorIds = new(StringComparer.OrdinalIgnoreCase)
    {
        "acid_blob", "alien", "alpaca", "angle", "armadillo", "assimilator", "bandit", "bear",
        "bee", "beetle", "bioblob", "buffalo", "butterfly", "candy", "capybara", "cat",
        "chicken", "cold_one", "coolbeak", "cow", "crab", "crocodile", "crystal", "crystal_sword",
        "demon", "dog", "druid", "dwarf", "elf", "evil_mage", "fairy", "fire_dlemental",
        "fire_elemental", "fire_elemental_man", "fire_elemental_blob", "fire_elemental_horse",
        "fire_elemental_slug", "fire_elemental_snake", "fire_skull", "flower_bud", "fly", "fox",
        "frog", "garl", "ghost", "goat", "grasshopper", "greg", "hopper", "human", "hyena",
        "jumpy_skull", "lil_pumpkin", "liliar", "monke", "monkey", "necromancer", "orc", "ostrich",
        "penguin", "piranha", "rabbit", "raccoon", "rat", "rhino", "scorp", "scorpion", "seal",
        "sheep", "skeleton", "smore", "snake", "snowman", "turtle", "unicorn", "white_mage", "wolf"
    };

    private static readonly string[] s_links =
    {
        "data", "asset", "kingdom", "city", "leader", "founder", "head", "actor", "unit", "race",
        "species", "subspecies", "family", "clan", "culture", "language", "members", "units",
        "author", "creator", "author_kingdom", "creator_kingdom", "author_city", "creator_city"
    };

    private static readonly string[] s_idMembers =
    {
        "id", "species_id", "race_id", "original_actor_asset", "originalActorAsset", "actor_asset",
        "actorAsset", "creator_species_id", "creatorSpeciesId", "author_species_id", "authorSpeciesId",
        "creator_subspecies_id", "creatorSubspeciesId", "author_subspecies_id", "authorSubspeciesId"
    };

    internal static string SmallGenerator(string category) =>
        string.IsNullOrWhiteSpace(category) ? null : $"civ_smallfolk_{category}";

    internal static string UnknownGenerator(string category) =>
        string.IsNullOrWhiteSpace(category) ? null : $"civ_unknown_{category}";

    internal static bool IsCuratedPlainActorId(string id)
    {
        return s_curatedPlainActorIds.Contains(Normalize(id));
    }

    internal static bool IsSmallCreature(object root)
    {
        return FindSmallCreatureId(root) != null;
    }

    internal static bool IsSmallCreature(object first, object second)
    {
        return FindSmallCreatureId(first) != null || FindSmallCreatureId(second) != null;
    }

    internal static bool IsSmallCreature(object[] args)
    {
        if (args == null) return false;
        foreach (object arg in args)
            if (FindSmallCreatureId(arg) != null) return true;
        return false;
    }

    internal static string FindSmallCreatureId(object root)
    {
        if (root == null) return null;

        var queue = new Queue<Tuple<object, int>>();
        var seen = new HashSet<object>();
        queue.Enqueue(Tuple.Create(root, 0));

        while (queue.Count > 0)
        {
            Tuple<object, int> pair = queue.Dequeue();
            object current = pair.Item1;
            int depth = pair.Item2;
            if (current == null || depth > 5 || seen.Contains(current)) continue;
            seen.Add(current);

            string direct = Normalize(current as string);
            string small = CanonicalSmallId(direct);
            if (small != null) return small;

            foreach (string member in s_idMembers)
            {
                small = CanonicalSmallId(Normalize(Read(current, member) as string));
                if (small != null) return small;
            }

            foreach (string link in s_links)
            {
                object value = Read(current, link);
                if (value == null || value is string) continue;

                if (value is IEnumerable enumerable)
                {
                    int count = 0;
                    foreach (object item in enumerable)
                    {
                        if (item != null) queue.Enqueue(Tuple.Create(item, depth + 1));
                        if (++count >= 24) break;
                    }
                }
                else
                {
                    queue.Enqueue(Tuple.Create(value, depth + 1));
                }
            }
        }

        return null;
    }

    internal static string FindSmallCreatureId(object instance, object[] args)
    {
        string id = FindSmallCreatureId(instance);
        if (id != null || args == null) return id;
        foreach (object arg in args)
        {
            id = FindSmallCreatureId(arg);
            if (id != null) return id;
        }
        return null;
    }

    private static string CanonicalSmallId(string value)
    {
        if (string.IsNullOrEmpty(value)) return null;

        string id = value;
        if (id.StartsWith("civ_")) id = id.Substring(4);

        string[] removableSuffixes = { "_people", "_civilization", "_humanoid", "_person", "_unit" };
        foreach (string suffix in removableSuffixes)
        {
            if (id.EndsWith(suffix, StringComparison.OrdinalIgnoreCase))
            {
                id = id.Substring(0, id.Length - suffix.Length);
                break;
            }
        }

        foreach (string alias in s_smallAliases)
        {
            if (id == alias || id.StartsWith(alias + "_", StringComparison.OrdinalIgnoreCase))
            {
                if (alias == "dung_beetle" || alias == "dungbeetle" || alias == "dunglord" || alias == "dung_lord")
                    return "beetle";
                return alias;
            }
        }

        return null;
    }

    private static string Normalize(string value)
    {
        return string.IsNullOrWhiteSpace(value)
            ? ""
            : value.Trim().ToLowerInvariant().Replace(" ", "_").Replace("-", "_");
    }

    private static object Read(object source, string member)
    {
        if (source == null) return null;
        Type type = source.GetType();
        const BindingFlags flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.IgnoreCase;
        try
        {
            PropertyInfo property = type.GetProperty(member, flags);
            if (property != null && property.GetIndexParameters().Length == 0)
                return property.GetValue(source, null);
            FieldInfo field = type.GetField(member, flags);
            if (field != null) return field.GetValue(source);
        }
        catch { }
        return null;
    }
}
