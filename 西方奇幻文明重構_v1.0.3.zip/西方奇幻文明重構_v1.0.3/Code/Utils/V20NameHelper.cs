using System;
using System.Reflection;
using System.Collections.Generic;

namespace Chinese_Name;

internal static class V20NameHelper
{
    private static object Get(object obj, string member)
    {
        if (obj == null) return null;
        Type t = obj.GetType();
        try
        {
            PropertyInfo p = t.GetProperty(member, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.IgnoreCase);
            if (p != null && p.GetIndexParameters().Length == 0) return p.GetValue(obj);
            FieldInfo f = t.GetField(member, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.IgnoreCase);
            if (f != null) return f.GetValue(obj);
        }
        catch { }
        return null;
    }

    private static string NormalizeId(object value)
    {
        string s = value as string;
        if (string.IsNullOrWhiteSpace(s)) return "";
        return s.Trim().ToLowerInvariant().Replace(" ", "_").Replace("-", "_");
    }

    private static bool IsTrue(object value)
    {
        if (value is bool b) return b;
        string s = value as string;
        return !string.IsNullOrEmpty(s) && s.Equals("true", StringComparison.OrdinalIgnoreCase);
    }

    private static bool MatchesExplicit(string value, string[] exact, string[] contains)
    {
        if (string.IsNullOrEmpty(value)) return false;
        foreach (string token in exact)
            if (value == token) return true;
        foreach (string token in contains)
            if (value.Contains(token)) return true;
        return false;
    }

    private static bool MatchesPlain(string value, string[] plain)
    {
        if (string.IsNullOrEmpty(value)) return false;
        foreach (string token in plain)
            if (value == token) return true;
        return false;
    }

    private static bool IsCivilization(object root, string[] explicitExact, string[] explicitContains, string[] plainIds)
    {
        // V35.2 隔離守則：明確文明 ID 可直接成立；裸普通物種 ID 必須同時找到 civ=true。
        // 因此 monkey/wolf/snake 等普通生物不會只因 ID 相同而吃到智慧文明命名。
        var queue = new Queue<Tuple<object, int>>();
        var seen = new HashSet<object>();
        queue.Enqueue(Tuple.Create(root, 0));
        string[] links = { "data", "kingdom", "city", "leader", "founder", "head", "actor", "unit", "race", "asset", "species", "members",
                           "author", "creator", "author_kingdom", "creator_kingdom", "author_city", "creator_city", "subspecies" };
        string[] ids = { "id", "species_id", "race_id", "original_actor_asset", "originalActorAsset", "actor_asset", "actorAsset",
                         "creator_species_id", "creatorSpeciesId", "author_species_id", "authorSpeciesId",
                         "creator_subspecies_id", "creatorSubspeciesId", "author_subspecies_id", "authorSubspeciesId" };
        bool foundPlain = false;
        bool foundCivilizedAsset = false;
        while (queue.Count > 0)
        {
            var pair = queue.Dequeue();
            object obj = pair.Item1;
            int depth = pair.Item2;
            if (obj == null || depth > 5 || seen.Contains(obj)) continue;
            seen.Add(obj);

            string own = NormalizeId(obj);
            if (MatchesExplicit(own, explicitExact, explicitContains)) return true;
            if (MatchesPlain(own, plainIds)) foundPlain = true;
            if (IsTrue(Get(obj, "civ"))) foundCivilizedAsset = true;

            foreach (string id in ids)
            {
                string value = NormalizeId(Get(obj, id));
                if (MatchesExplicit(value, explicitExact, explicitContains)) return true;
                if (MatchesPlain(value, plainIds)) foundPlain = true;
            }
            if (foundPlain && foundCivilizedAsset) return true;

            foreach (string link in links)
            {
                object value = Get(obj, link);
                if (value == null || value is string) continue;
                if (value is System.Collections.IEnumerable enumerable)
                {
                    int n = 0;
                    foreach (object item in enumerable)
                    {
                        if (item != null) queue.Enqueue(Tuple.Create(item, depth + 1));
                        if (++n >= 8) break;
                    }
                }
                else queue.Enqueue(Tuple.Create(value, depth + 1));
            }
        }
        return foundPlain && foundCivilizedAsset;
    }

    // V72.5：只辨識沒有 civ 標記的普通動物。
    // 用於家庭與亞種，避免普通動物吃到智慧文明資料，也避免智慧文明反吃普通動物資料。
    internal static string FindOrdinaryAnimalId(object root, string[] allowedIds)
    {
        if (root == null || allowedIds == null || allowedIds.Length == 0) return null;

        var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (string id in allowedIds)
        {
            string normalized = NormalizeId(id);
            if (!string.IsNullOrEmpty(normalized)) allowed.Add(normalized);
        }

        var queue = new Queue<Tuple<object, int>>();
        var seen = new HashSet<object>();
        queue.Enqueue(Tuple.Create(root, 0));

        string[] links = { "data", "kingdom", "city", "leader", "founder", "head", "actor", "unit", "race", "asset", "species", "members",
                           "author", "creator", "author_kingdom", "creator_kingdom", "author_city", "creator_city", "subspecies" };
        string[] idMembers = { "id", "species_id", "race_id", "original_actor_asset", "originalActorAsset", "actor_asset", "actorAsset",
                               "creator_species_id", "creatorSpeciesId", "author_species_id", "authorSpeciesId",
                               "creator_subspecies_id", "creatorSubspeciesId", "author_subspecies_id", "authorSubspeciesId" };

        string found = null;
        bool civilized = false;

        while (queue.Count > 0)
        {
            var pair = queue.Dequeue();
            object obj = pair.Item1;
            int depth = pair.Item2;
            if (obj == null || depth > 5 || seen.Contains(obj)) continue;
            seen.Add(obj);

            string own = NormalizeId(obj);
            if (own.StartsWith("civ_") || own.Contains("_people") || own.Contains("_civilization")) civilized = true;
            if (allowed.Contains(own) && found == null) found = own;
            if (IsTrue(Get(obj, "civ"))) civilized = true;

            foreach (string member in idMembers)
            {
                string value = NormalizeId(Get(obj, member));
                if (value.StartsWith("civ_") || value.Contains("_people") || value.Contains("_civilization")) civilized = true;
                if (allowed.Contains(value) && found == null) found = value;
            }

            foreach (string link in links)
            {
                object value = Get(obj, link);
                if (value == null || value is string) continue;
                if (value is System.Collections.IEnumerable enumerable)
                {
                    int n = 0;
                    foreach (object item in enumerable)
                    {
                        if (item != null) queue.Enqueue(Tuple.Create(item, depth + 1));
                        if (++n >= 16) break;
                    }
                }
                else queue.Enqueue(Tuple.Create(value, depth + 1));
            }
        }

        return civilized ? null : found;
    }

    // V1.0.3：搜尋已知精確 ID，但不因 civ=true 排除。
    // 僅供「同一生物有多個形態 Actor ID、開智後仍應共用同一家庭／亞種」的特殊生物使用。
    internal static string FindKnownId(object root, string[] allowedIds)
    {
        if (root == null || allowedIds == null || allowedIds.Length == 0) return null;

        var allowed = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        foreach (string id in allowedIds)
        {
            string normalized = NormalizeId(id);
            if (!string.IsNullOrEmpty(normalized)) allowed.Add(normalized);
        }

        var queue = new Queue<Tuple<object, int>>();
        var seen = new HashSet<object>();
        queue.Enqueue(Tuple.Create(root, 0));

        string[] links = { "data", "kingdom", "city", "leader", "founder", "head", "actor", "unit", "race", "asset", "species", "members",
                           "author", "creator", "author_kingdom", "creator_kingdom", "author_city", "creator_city", "subspecies" };
        string[] idMembers = { "id", "species_id", "race_id", "original_actor_asset", "originalActorAsset", "actor_asset", "actorAsset",
                               "creator_species_id", "creatorSpeciesId", "author_species_id", "authorSpeciesId",
                               "creator_subspecies_id", "creatorSubspeciesId", "author_subspecies_id", "authorSubspeciesId" };

        while (queue.Count > 0)
        {
            var pair = queue.Dequeue();
            object obj = pair.Item1;
            int depth = pair.Item2;
            if (obj == null || depth > 5 || seen.Contains(obj)) continue;
            seen.Add(obj);

            string own = NormalizeId(obj);
            if (allowed.Contains(own)) return own;

            foreach (string member in idMembers)
            {
                string value = NormalizeId(Get(obj, member));
                if (allowed.Contains(value)) return value;
            }

            foreach (string link in links)
            {
                object value = Get(obj, link);
                if (value == null || value is string) continue;
                if (value is System.Collections.IEnumerable enumerable)
                {
                    int n = 0;
                    foreach (object item in enumerable)
                    {
                        if (item != null) queue.Enqueue(Tuple.Create(item, depth + 1));
                        if (++n >= 16) break;
                    }
                }
                else queue.Enqueue(Tuple.Create(value, depth + 1));
            }
        }

        return null;
    }

    internal static bool IsMonkey(object root) => IsCivilization(root,
        new[] { "monke", "monkey_people", "monkey_civilization" },
        new[] { "civ_monkey", "civ_monke" },
        new[] { "monkey" });

    internal static bool IsHopper(object root) => IsCivilization(root,
        new[] { "hopper_people", "rabbit_people", "rabbit_civilization" },
        new[] { "civ_hopper", "civ_rabbit" },
        new[] { "hopper", "rabbit" });

    internal static bool IsScorp(object root) => IsCivilization(root,
        new[] { "scorp", "scorp_people", "scorpion_people" },
        new[] { "civ_scorp", "civ_scorpion" },
        new[] { "scorpion" });

    internal static bool IsCoolbeak(object root) => IsCivilization(root,
        new[] { "coolbeak", "penguin_people", "penguin_civilization", "penguin_humanoid" },
        new[] { "civ_coolbeak", "civ_penguin" },
        new[] { "penguin" });

    internal static bool IsLiliar(object root) => IsCivilization(root,
        new[] { "liliar", "lulliar", "liliar_people" },
        new[] { "civ_liliar", "civ_lulliar" },
        new[] { "flower_bud" });

    internal static bool IsBuffolon(object root) => IsCivilization(root,
        new[] { "buffolon", "buffolon_people", "buffalo_people", "buffalo_civilization", "buffolon_civilization", "civ_buffalo", "civ_buffolon" },
        new[] { "civ_buffalo_", "civ_buffolon_" },
        new[] { "buffalo" });

    internal static bool IsArmaldar(object root) => IsCivilization(root,
        new[] { "armaldar", "armaldar_people", "armadillo_people", "armadillo_civilization", "armaldar_civilization", "civ_armadillo", "civ_armaldar" },
        new[] { "civ_armadillo_", "civ_armaldar_" },
        new[] { "armadillo" });

    internal static bool IsPunkcorn(object root) => IsCivilization(root,
        new[] { "punkcorn", "punk_corn", "punkcorn_people", "unicorn_people", "unicorn_civilization", "punkcorn_civilization", "civ_unicorn", "civ_punkcorn" },
        new[] { "civ_unicorn_", "civ_punkcorn_" },
        new[] { "unicorn" });

    internal static bool IsBaakin(object root) => IsCivilization(root,
        new[] { "baakin", "baakin_people", "sheep_people", "sheep_civilization", "baakin_civilization", "civ_sheep", "civ_baakin" },
        new[] { "civ_sheep_", "civ_baakin_" },
        new[] { "sheep" });


    internal static bool IsMootaur(object root) => IsCivilization(root,
        new[] { "mootaur", "mootaur_people", "cow_people", "cow_civilization", "mootaur_civilization", "civ_cow", "civ_mootaur" },
        new[] { "civ_cow_", "civ_mootaur_" },
        new[] { "cow" });

    internal static bool IsSlypaw(object root) => IsCivilization(root,
        new[] { "slypaw", "sly_paw", "slypaw_people", "fox_people", "fox_civilization", "slypaw_civilization", "civ_fox", "civ_slypaw" },
        new[] { "civ_fox_", "civ_slypaw_" },
        new[] { "fox" });

    internal static bool IsPecklord(object root) => IsCivilization(root,
        new[] { "pecklord", "peck_lord", "pecklord_people", "chicken_people", "chichen_people", "chicken_civilization", "chichen_civilization", "pecklord_civilization", "civ_chicken", "civ_chichen", "civ_pecklord" },
        new[] { "civ_chicken_", "civ_chichen_", "civ_pecklord_" },
        new[] { "chicken", "chichen" });

    internal static bool IsBarkfolk(object root) => IsCivilization(root,
        new[] { "barkfolk", "bark_folk", "barkfolk_people", "dog_people", "dog_civilization", "barkfolk_civilization", "civ_dog", "civ_barkfolk" },
        new[] { "civ_dog_", "civ_barkfolk_" },
        new[] { "dog" });

    internal static bool IsAcidGentleman(object root) => IsCivilization(root,
        new[] { "acid_gentleman", "acidgentleman", "acid_gentleman_people", "acid_blob_people", "acid_blob_civilization", "acid_gentleman_civilization", "civ_acid_gentleman", "civ_acid_blob" },
        new[] { "civ_acid_gentleman_", "civ_acid_blob_" },
        new[] { "acid_blob" });

    internal static bool IsGarlicMan(object root) => IsCivilization(root,
        new[] { "garlic_man", "garlicman", "garlic_man_people", "garl_people", "garl_civilization", "garlic_man_civilization", "civ_garlic_man", "civ_garl" },
        new[] { "civ_garlic_man_", "civ_garl_" },
        new[] { "garl" });

    internal static bool IsLemonMan(object root) => IsCivilization(root,
        new[] { "lemon_man", "lemonmen", "lemon_men", "lemon_man_people", "lemon_people", "lemon_civilization", "civ_lemon_man", "civ_lemon_men" },
        new[] { "civ_lemon_man_", "civ_lemon_men_", "civ_bitba_" },
        new[] { "bitba" });

    internal static bool IsPlagueDoctor(object root) => IsCivilization(root,
        new[] { "plague_doctor", "plague_doctor_people", "plague_doctor_civilization", "doctor_people", "civ_plague_doctor" },
        new[] { "civ_plague_doctor_" },
        Array.Empty<string>());

    // V54：Demon 與 Fairy 採 Special Civilization 全套規格。
    // plain actor ID 本身即應導向完整文明，不要求額外 civ=true。
    internal static bool IsDemon(object root) => IsCivilization(root,
        new[] { "demon", "demon_people", "demon_civilization", "civ_demon" },
        new[] { "civ_demon_" },
        Array.Empty<string>());

    internal static bool IsFairy(object root) => IsCivilization(root,
        new[] { "fairy", "fairy_people", "fairy_civilization", "angel_people", "angel_civilization", "civ_fairy" },
        new[] { "civ_fairy_" },
        Array.Empty<string>());

    // V55：Evil Mage 與 Alien 採 Special Civilization 全套規格。
    // plain actor ID 本身即導向完整文明，不要求額外 civ=true。
    internal static bool IsEvilMage(object root) => IsCivilization(root,
        new[] { "evil_mage", "evilmage", "evil_mage_people", "evil_mage_civilization", "civ_evil_mage" },
        new[] { "civ_evil_mage_" },
        Array.Empty<string>());

    internal static bool IsAlien(object root) => IsCivilization(root,
        new[] { "alien", "alien_people", "alien_civilization", "civ_alien" },
        new[] { "civ_alien_" },
        Array.Empty<string>());

    // V56：White Mage 與 Cold One 採 Special Civilization 全套規格。
    // plain actor ID 本身即導向完整文明，不要求額外 civ=true。
    internal static bool IsWhiteMage(object root) => IsCivilization(root,
        new[] { "white_mage", "whitemage", "white_mage_people", "white_mage_civilization", "civ_white_mage" },
        new[] { "civ_white_mage_" },
        Array.Empty<string>());

    internal static bool IsColdOne(object root) => IsCivilization(root,
        new[] { "cold_one", "coldone", "cold_one_people", "cold_one_civilization", "civ_cold_one" },
        new[] { "civ_cold_one_" },
        Array.Empty<string>());

    // V57：Angle 與 Skeleton 採 Special Civilization 全套規格。
    // Angle 真實 Actor ID 為 angle（不是 angel）；Skeleton 即使由其他文明召喚，也依當前 skeleton ID 使用自身命名。
    internal static bool IsAngle(object root) => IsCivilization(root,
        new[] { "angle", "angle_people", "angle_civilization", "civ_angle" },
        new[] { "civ_angle_" },
        Array.Empty<string>());

    internal static bool IsSkeleton(object root) => IsCivilization(root,
        new[] { "skeleton", "skeleton_people", "skeleton_civilization", "civ_skeleton" },
        new[] { "civ_skeleton_" },
        Array.Empty<string>());

    // V58：Snowman 與 Druid 採 Special Civilization 全套規格。
    // plain actor ID 本身即導向完整文明，不要求額外 civ=true。
    internal static bool IsSnowman(object root) => IsCivilization(root,
        new[] { "snowman", "snowman_people", "snowman_civilization", "civ_snowman" },
        new[] { "civ_snowman_" },
        Array.Empty<string>());

    internal static bool IsDruid(object root) => IsCivilization(root,
        new[] { "druid", "druid_people", "druid_civilization", "civ_druid" },
        new[] { "civ_druid_" },
        Array.Empty<string>());

    // V59：Ghost 與 Bandit 採 Special Civilization 全套規格。
    // Ghost 由靈魂聚合繁衍；Bandit 以獨立 bandit Actor ID 路由，不沿用人類或魔道模板。
    internal static bool IsGhost(object root) => IsCivilization(root,
        new[] { "ghost", "ghost_people", "ghost_civilization", "civ_ghost" },
        new[] { "civ_ghost_" },
        Array.Empty<string>());

    internal static bool IsBandit(object root) => IsCivilization(root,
        new[] { "bandit", "bandit_people", "bandit_civilization", "civ_bandit" },
        new[] { "civ_bandit_" },
        Array.Empty<string>());

    // V60：Greg 與 Necromancer 採 Special Civilization 全套規格。
    // Greg 使用獨立 greg Actor ID；Necromancer 本體使用自身命名，召喚出的 skeleton 仍由 IsSkeleton 分流。
    // V61：Jumpy Skull 與 Fire Skull 採 Special Civilization 全套規格。
    // 三種骨類文明完全分流：skeleton、jumpy_skull、fire_skull 皆依自身 Actor ID 路由。
    internal static bool IsJumpySkull(object root) => IsCivilization(root,
        new[] { "jumpy_skull", "jumpyskull", "rude_skull", "jumpy_skull_people", "jumpy_skull_civilization", "civ_jumpy_skull" },
        new[] { "civ_jumpy_skull_" },
        Array.Empty<string>());

    internal static bool IsFireSkull(object root) => IsCivilization(root,
        new[] { "fire_skull", "fireskull", "fire_skull_people", "fire_skull_civilization", "civ_fire_skull" },
        new[] { "civ_fire_skull_" },
        Array.Empty<string>());

    internal static bool IsGreg(object root) => IsCivilization(root,
        new[] { "greg", "greg_people", "greg_civilization", "civ_greg" },
        new[] { "civ_greg_" },
        Array.Empty<string>());

    internal static bool IsNecromancer(object root) => IsCivilization(root,
        new[] { "necromancer", "necromancer_people", "necromancer_civilization", "civ_necromancer" },
        new[] { "civ_necromancer_" },
        Array.Empty<string>());

    internal static bool IsLulclaw(object root) => IsCivilization(root,
        new[] { "lulclaw", "lul_claw", "lulclaw_people", "hyena_people", "hyena_civilization", "lulclaw_civilization", "civ_hyena", "civ_lulclaw" },
        new[] { "civ_hyena_", "civ_lulclaw_" },
        new[] { "hyena" });

    internal static bool IsNibling(object root) => IsCivilization(root,
        new[] { "nibling", "nibling_people", "rat_people", "rat_civilization", "nibling_civilization", "civ_rat", "civ_nibling" },
        new[] { "civ_rat_", "civ_nibling_" },
        new[] { "rat" });

    internal static bool IsCharmaca(object root) => IsCivilization(root,
        new[] { "charmaca", "charmaca_people", "alpaca_people", "alpaca_civilization", "charmaca_civilization", "civ_alpaca", "civ_charmaca" },
        new[] { "civ_alpaca_", "civ_charmaca_" },
        new[] { "alpaca" });

    internal static bool IsHerdor(object root) => IsCivilization(root,
        new[] { "herdor", "herdor_people", "goat_people", "goat_civilization", "herdor_civilization", "civ_goat", "civ_herdor" },
        new[] { "civ_goat_", "civ_herdor_" },
        new[] { "goat" });

    internal static bool IsRibbit(object root) => IsCivilization(root,
        new[] { "ribbit", "ribbit_people", "frog_people", "frog_civilization", "ribbit_civilization", "civ_frog", "civ_ribbit" },
        new[] { "civ_frog_", "civ_ribbit_" },
        new[] { "frog" });

    internal static bool IsGnapkin(object root) => IsCivilization(root,
        new[] { "gnapkin", "gnapkin_people", "piranha_people", "piranha_civilization", "gnapkin_civilization", "civ_piranha", "civ_gnapkin" },
        new[] { "civ_piranha_", "civ_gnapkin_" },
        new[] { "piranha" });

    internal static bool IsReptiloid(object root) => IsCivilization(root,
        new[] { "reptiloid", "reptiloid_people", "crocodile_people", "crocodile_civilization", "reptiloid_civilization", "civ_crocodile", "civ_reptiloid" },
        new[] { "civ_crocodile_", "civ_reptiloid_" },
        new[] { "crocodile" });

    internal static bool IsMeowmorph(object root) => IsCivilization(root,
        new[] { "meowmorph", "meow_morph", "meowmorph_people", "cat_people", "cat_civilization", "meowmorph_civilization", "civ_cat", "civ_meowmorph", "civ_meow_morph" },
        new[] { "civ_cat_", "civ_meowmorph_", "civ_meow_morph_" },
        new[] { "cat" });

    internal static bool IsDunglord(object root) => IsCivilization(root,
        new[] { "dunglord", "dung_lord", "dungbeetle", "dunglord_people", "dung_beetle_people", "dunglord_civilization" },
        new[] { "civ_beetle", "civ_dunglord", "civ_dung_lord", "civ_dung_beetle" },
        new[] { "beetle", "dung_beetle" });

    internal static bool IsArmococ(object root) => IsCivilization(root,
        new[] { "armococ", "armococ_people", "armococ_civilization", "rhino_people", "rhino_civilization" },
        new[] { "civ_armococ", "civ_rhino" },
        new[] { "rhino" });

    internal static bool IsGrranth(object root) => IsCivilization(root,
        new[] { "grranth", "grranth_people", "bear_people", "bear_civilization" },
        new[] { "civ_grranth", "civ_bear" },
        new[] { "bear" });

    internal static bool IsCandyMan(object root) => IsCivilization(root,
        new[] { "candy_man", "candyman", "candy_people", "candy_civilization" },
        new[] { "civ_candy", "civ_candy_man", "civ_candyman" },
        new[] { "smore" });

    internal static bool IsCrab(object root) => IsCivilization(root,
        new[] { "crablin", "crab_people", "crab_civilization" },
        new[] { "civ_crab", "civ_crablin" },
        new[] { "crab" });

    internal static bool IsTurtok(object root) => IsCivilization(root,
        new[] { "turtok" },
        new[] { "civ_turtle", "civ_turtok" },
        new[] { "turtle" });

    internal static bool IsNavySeal(object root) => IsCivilization(root,
        new[] { "navi_seal", "navy_seal" },
        new[] { "civ_seal", "civ_navi_seal", "civ_navy_seal" },
        new[] { "seal" });

    internal static bool IsCapybara(object root) => IsCivilization(root,
        new[] { "chillbara", "chill_bara", "capybara_people" },
        new[] { "civ_capybara" },
        new[] { "capybara" });

    internal static bool IsCrystal(object root) => IsCivilization(root,
        new[] { "crystal_golem", "crystal_people" },
        new[] { "civ_crystal" },
        new[] { "crystal_sword", "crystal", "crystalsword" });

    internal static bool IsSnake(object root) => IsCivilization(root,
        new[] { "snok", "snake_people", "snake_civilization" },
        new[] { "civ_snake", "civ_snok" },
        new[] { "snake" });

    internal static bool IsWolf(object root) => IsCivilization(root,
        new[] { "howleer", "wolf_people", "wolf_civilization" },
        new[] { "civ_wolf", "civ_howleer" },
        new[] { "wolf" });


    // V53.2：某些特殊前身建立第一批文明資料時，傳入物件只保留原始物種 ID，
    // 且不一定能在同一條物件鏈上找到 civ=true。這三個方法只供「文明資料」路由使用，
    // 不得用於人物、家庭、亞種，避免破壞原始生物分流。
    private static bool ContainsPlainSourceId(object root, string[] plainIds)
    {
        var queue = new Queue<Tuple<object, int>>();
        var seen = new HashSet<object>();
        queue.Enqueue(Tuple.Create(root, 0));
        string[] links = { "data", "kingdom", "city", "leader", "founder", "head", "actor", "unit", "race", "asset", "species", "members",
                           "author", "creator", "author_kingdom", "creator_kingdom", "author_city", "creator_city", "subspecies" };
        string[] ids = { "id", "species_id", "race_id", "original_actor_asset", "originalActorAsset", "actor_asset", "actorAsset",
                         "creator_species_id", "creatorSpeciesId", "author_species_id", "authorSpeciesId",
                         "creator_subspecies_id", "creatorSubspeciesId", "author_subspecies_id", "authorSubspeciesId" };

        while (queue.Count > 0)
        {
            var pair = queue.Dequeue();
            object obj = pair.Item1;
            int depth = pair.Item2;
            if (obj == null || depth > 5 || seen.Contains(obj)) continue;
            seen.Add(obj);

            if (MatchesPlain(NormalizeId(obj), plainIds)) return true;
            foreach (string id in ids)
            {
                if (MatchesPlain(NormalizeId(Get(obj, id)), plainIds)) return true;
            }

            foreach (string link in links)
            {
                object value = Get(obj, link);
                if (value == null || value is string) continue;
                if (value is System.Collections.IEnumerable enumerable)
                {
                    int n = 0;
                    foreach (object item in enumerable)
                    {
                        if (item != null) queue.Enqueue(Tuple.Create(item, depth + 1));
                        if (++n >= 8) break;
                    }
                }
                else queue.Enqueue(Tuple.Create(value, depth + 1));
            }
        }
        return false;
    }

    internal static bool IsLiliarCivilizationSource(object root) =>
        IsLiliar(root) || ContainsPlainSourceId(root, new[] { "flower_bud", "flowerbud" });

    internal static bool IsCandyManCivilizationSource(object root) =>
        IsCandyMan(root) || ContainsPlainSourceId(root, new[] { "smore" });

    internal static bool IsCrystalCivilizationSource(object root) =>
        IsCrystal(root) || ContainsPlainSourceId(root, new[] { "crystal_sword", "crystalsword" });

    internal static void SetName(object root, string name)
    {
        if (root == null || string.IsNullOrWhiteSpace(name)) return;
        object data = Get(root, "data");
        if (TrySet(data, "name", name)) return;
        TrySet(root, "name", name);
    }

    private static bool TrySet(object obj, string member, string value)
    {
        if (obj == null) return false;
        Type t = obj.GetType();
        try
        {
            PropertyInfo p = t.GetProperty(member, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.IgnoreCase);
            if (p != null && p.CanWrite && p.PropertyType == typeof(string)) { p.SetValue(obj, value); return true; }
            FieldInfo f = t.GetField(member, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.IgnoreCase);
            if (f != null && f.FieldType == typeof(string)) { f.SetValue(obj, value); return true; }
        }
        catch { }
        return false;
    }
}
