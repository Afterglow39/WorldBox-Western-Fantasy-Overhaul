using System;
using System.Runtime.CompilerServices;

namespace Chinese_Name;

/// <summary>
/// V1.0.6: actor names use only the current actor asset, never kingdom/city/member graphs.
/// Cache routing per asset (not per actor). Mutable IDs and civ flags invalidate the entry.
/// The cache holds template IDs only; generator lookup stays live for resource reloads.
/// </summary>
internal static class ActorNameRouter
{
    private sealed class RouteCache
    {
        internal string RawId;
        internal bool Civilized;
        internal string TemplateId;
        internal bool Initialized;
    }

    private sealed class Rule
    {
        internal readonly string TemplateId;
        internal readonly string[] Exact;
        internal readonly string[] Contains;
        internal readonly string[] Plain;
        internal Rule(string templateId, string[] exact, string[] contains, string[] plain)
        {
            TemplateId = templateId;
            Exact = exact;
            Contains = contains;
            Plain = plain;
        }
        internal bool Matches(string id, bool civilized)
        {
            foreach (string token in Exact) if (id == token) return true;
            foreach (string token in Contains) if (id.Contains(token)) return true;
            if (civilized)
                foreach (string token in Plain) if (id == token) return true;
            return false;
        }
    }

    private static readonly ConditionalWeakTable<ActorAsset, RouteCache> s_routes =
        new ConditionalWeakTable<ActorAsset, RouteCache>();

    // Keep v1.0.5 actor routing order, including special creatures and plain/civ separation.
    private static readonly Rule[] s_rules = new Rule[]
    {
        new Rule("civ_buffalo_name", new string[] { "buffolon", "buffolon_people", "buffalo_people", "buffalo_civilization", "buffolon_civilization", "civ_buffalo", "civ_buffolon" }, new string[] { "civ_buffalo_", "civ_buffolon_" }, new string[] { "buffalo" }), // IsBuffolon
        new Rule("civ_armadillo_name", new string[] { "armaldar", "armaldar_people", "armadillo_people", "armadillo_civilization", "armaldar_civilization", "civ_armadillo", "civ_armaldar" }, new string[] { "civ_armadillo_", "civ_armaldar_" }, new string[] { "armadillo" }), // IsArmaldar
        new Rule("civ_unicorn_name", new string[] { "punkcorn", "punk_corn", "punkcorn_people", "unicorn_people", "unicorn_civilization", "punkcorn_civilization", "civ_unicorn", "civ_punkcorn" }, new string[] { "civ_unicorn_", "civ_punkcorn_" }, new string[] { "unicorn" }), // IsPunkcorn
        new Rule("civ_sheep_name", new string[] { "baakin", "baakin_people", "sheep_people", "sheep_civilization", "baakin_civilization", "civ_sheep", "civ_baakin" }, new string[] { "civ_sheep_", "civ_baakin_" }, new string[] { "sheep" }), // IsBaakin
        new Rule("civ_cow_name", new string[] { "mootaur", "mootaur_people", "cow_people", "cow_civilization", "mootaur_civilization", "civ_cow", "civ_mootaur" }, new string[] { "civ_cow_", "civ_mootaur_" }, new string[] { "cow" }), // IsMootaur
        new Rule("civ_fox_name", new string[] { "slypaw", "sly_paw", "slypaw_people", "fox_people", "fox_civilization", "slypaw_civilization", "civ_fox", "civ_slypaw" }, new string[] { "civ_fox_", "civ_slypaw_" }, new string[] { "fox" }), // IsSlypaw
        new Rule("civ_chicken_name", new string[] { "pecklord", "peck_lord", "pecklord_people", "chicken_people", "chichen_people", "chicken_civilization", "chichen_civilization", "pecklord_civilization", "civ_chicken", "civ_chichen", "civ_pecklord" }, new string[] { "civ_chicken_", "civ_chichen_", "civ_pecklord_" }, new string[] { "chicken", "chichen" }), // IsPecklord
        new Rule("civ_dog_name", new string[] { "barkfolk", "bark_folk", "barkfolk_people", "dog_people", "dog_civilization", "barkfolk_civilization", "civ_dog", "civ_barkfolk" }, new string[] { "civ_dog_", "civ_barkfolk_" }, new string[] { "dog" }), // IsBarkfolk
        new Rule("civ_acid_gentleman_name", new string[] { "acid_gentleman", "acidgentleman", "acid_gentleman_people", "acid_blob_people", "acid_blob_civilization", "acid_gentleman_civilization", "civ_acid_gentleman", "civ_acid_blob" }, new string[] { "civ_acid_gentleman_", "civ_acid_blob_" }, new string[] { "acid_blob" }), // IsAcidGentleman
        new Rule("civ_garlic_man_name", new string[] { "garlic_man", "garlicman", "garlic_man_people", "garl_people", "garl_civilization", "garlic_man_civilization", "civ_garlic_man", "civ_garl" }, new string[] { "civ_garlic_man_", "civ_garl_" }, new string[] { "garl" }), // IsGarlicMan
        new Rule("civ_lemon_man_name", new string[] { "lemon_man", "lemonmen", "lemon_men", "lemon_man_people", "lemon_people", "lemon_civilization", "civ_lemon_man", "civ_lemon_men" }, new string[] { "civ_lemon_man_", "civ_lemon_men_" }, Array.Empty<string>()), // IsLemonMan
        new Rule("civ_plague_doctor_name", new string[] { "plague_doctor", "plague_doctor_people", "plague_doctor_civilization", "doctor_people", "civ_plague_doctor" }, new string[] { "civ_plague_doctor_" }, Array.Empty<string>()), // IsPlagueDoctor
        new Rule("civ_demon_name", new string[] { "demon", "demon_people", "demon_civilization", "civ_demon" }, new string[] { "civ_demon_" }, Array.Empty<string>()), // IsDemon
        new Rule("civ_fairy_name", new string[] { "fairy", "fairy_people", "fairy_civilization", "angel_people", "angel_civilization", "civ_fairy" }, new string[] { "civ_fairy_" }, Array.Empty<string>()), // IsFairy
        new Rule("civ_evil_mage_name", new string[] { "evil_mage", "evilmage", "evil_mage_people", "evil_mage_civilization", "civ_evil_mage" }, new string[] { "civ_evil_mage_" }, Array.Empty<string>()), // IsEvilMage
        new Rule("civ_alien_name", new string[] { "alien", "alien_people", "alien_civilization", "civ_alien" }, new string[] { "civ_alien_" }, Array.Empty<string>()), // IsAlien
        new Rule("civ_white_mage_name", new string[] { "white_mage", "whitemage", "white_mage_people", "white_mage_civilization", "civ_white_mage" }, new string[] { "civ_white_mage_" }, Array.Empty<string>()), // IsWhiteMage
        new Rule("civ_cold_one_name", new string[] { "cold_one", "coldone", "cold_one_people", "cold_one_civilization", "civ_cold_one" }, new string[] { "civ_cold_one_" }, Array.Empty<string>()), // IsColdOne
        new Rule("civ_angle_name", new string[] { "angle", "angle_people", "angle_civilization", "civ_angle" }, new string[] { "civ_angle_" }, Array.Empty<string>()), // IsAngle
        new Rule("civ_skeleton_name", new string[] { "skeleton", "skeleton_people", "skeleton_civilization", "civ_skeleton" }, new string[] { "civ_skeleton_" }, Array.Empty<string>()), // IsSkeleton
        new Rule("civ_snowman_name", new string[] { "snowman", "snowman_people", "snowman_civilization", "civ_snowman" }, new string[] { "civ_snowman_" }, Array.Empty<string>()), // IsSnowman
        new Rule("civ_druid_name", new string[] { "druid", "druid_people", "druid_civilization", "civ_druid" }, new string[] { "civ_druid_" }, Array.Empty<string>()), // IsDruid
        new Rule("civ_ghost_name", new string[] { "ghost", "ghost_people", "ghost_civilization", "civ_ghost" }, new string[] { "civ_ghost_" }, Array.Empty<string>()), // IsGhost
        new Rule("civ_bandit_name", new string[] { "bandit", "bandit_people", "bandit_civilization", "civ_bandit" }, new string[] { "civ_bandit_" }, Array.Empty<string>()), // IsBandit
        new Rule("civ_jumpy_skull_name", new string[] { "jumpy_skull", "jumpyskull", "rude_skull", "jumpy_skull_people", "jumpy_skull_civilization", "civ_jumpy_skull" }, new string[] { "civ_jumpy_skull_" }, Array.Empty<string>()), // IsJumpySkull
        new Rule("civ_fire_skull_name", new string[] { "fire_skull", "fireskull", "fire_skull_people", "fire_skull_civilization", "civ_fire_skull" }, new string[] { "civ_fire_skull_" }, Array.Empty<string>()), // IsFireSkull
        new Rule("civ_greg_name", new string[] { "greg", "greg_people", "greg_civilization", "civ_greg" }, new string[] { "civ_greg_" }, Array.Empty<string>()), // IsGreg
        new Rule("civ_necromancer_name", new string[] { "necromancer", "necromancer_people", "necromancer_civilization", "civ_necromancer" }, new string[] { "civ_necromancer_" }, Array.Empty<string>()), // IsNecromancer
        new Rule("civ_hyena_name", new string[] { "lulclaw", "lul_claw", "lulclaw_people", "hyena_people", "hyena_civilization", "lulclaw_civilization", "civ_hyena", "civ_lulclaw" }, new string[] { "civ_hyena_", "civ_lulclaw_" }, new string[] { "hyena" }), // IsLulclaw
        new Rule("civ_rat_name", new string[] { "nibling", "nibling_people", "rat_people", "rat_civilization", "nibling_civilization", "civ_rat", "civ_nibling" }, new string[] { "civ_rat_", "civ_nibling_" }, new string[] { "rat" }), // IsNibling
        new Rule("civ_alpaca_name", new string[] { "charmaca", "charmaca_people", "alpaca_people", "alpaca_civilization", "charmaca_civilization", "civ_alpaca", "civ_charmaca" }, new string[] { "civ_alpaca_", "civ_charmaca_" }, new string[] { "alpaca" }), // IsCharmaca
        new Rule("civ_goat_name", new string[] { "herdor", "herdor_people", "goat_people", "goat_civilization", "herdor_civilization", "civ_goat", "civ_herdor" }, new string[] { "civ_goat_", "civ_herdor_" }, new string[] { "goat" }), // IsHerdor
        new Rule("civ_frog_name", new string[] { "ribbit", "ribbit_people", "frog_people", "frog_civilization", "ribbit_civilization", "civ_frog", "civ_ribbit" }, new string[] { "civ_frog_", "civ_ribbit_" }, new string[] { "frog" }), // IsRibbit
        new Rule("civ_piranha_name", new string[] { "gnapkin", "gnapkin_people", "piranha_people", "piranha_civilization", "gnapkin_civilization", "civ_piranha", "civ_gnapkin" }, new string[] { "civ_piranha_", "civ_gnapkin_" }, new string[] { "piranha" }), // IsGnapkin
        new Rule("civ_crocodile_name", new string[] { "reptiloid", "reptiloid_people", "crocodile_people", "crocodile_civilization", "reptiloid_civilization", "civ_crocodile", "civ_reptiloid" }, new string[] { "civ_crocodile_", "civ_reptiloid_" }, new string[] { "crocodile" }), // IsReptiloid
        new Rule("civ_cat_name", new string[] { "meowmorph", "meow_morph", "meowmorph_people", "cat_people", "cat_civilization", "meowmorph_civilization", "civ_cat", "civ_meowmorph", "civ_meow_morph" }, new string[] { "civ_cat_", "civ_meowmorph_", "civ_meow_morph_" }, new string[] { "cat" }), // IsMeowmorph
        new Rule("civ_beetle_name", new string[] { "dunglord", "dung_lord", "dungbeetle", "dunglord_people", "dung_beetle_people", "dunglord_civilization" }, new string[] { "civ_beetle", "civ_dunglord", "civ_dung_lord", "civ_dung_beetle" }, new string[] { "beetle", "dung_beetle" }), // IsDunglord
        new Rule("civ_armococ_name", new string[] { "armococ", "armococ_people", "armococ_civilization", "rhino_people", "rhino_civilization" }, new string[] { "civ_armococ", "civ_rhino" }, new string[] { "rhino" }), // IsArmococ
        new Rule("civ_grranth_name", new string[] { "grranth", "grranth_people", "bear_people", "bear_civilization" }, new string[] { "civ_grranth", "civ_bear" }, new string[] { "bear" }), // IsGrranth
        new Rule("civ_candy_name", new string[] { "candy_man", "candyman", "candy_people", "candy_civilization" }, new string[] { "civ_candy", "civ_candy_man", "civ_candyman" }, new string[] { "smore" }), // IsCandyMan
        new Rule("civ_crab_name", new string[] { "crablin", "crab_people", "crab_civilization" }, new string[] { "civ_crab", "civ_crablin" }, new string[] { "crab" }), // IsCrab
        new Rule("civ_turtle_name", new string[] { "turtok" }, new string[] { "civ_turtle", "civ_turtok" }, new string[] { "turtle" }), // IsTurtok
        new Rule("civ_seal_name", new string[] { "navi_seal", "navy_seal" }, new string[] { "civ_seal", "civ_navi_seal", "civ_navy_seal" }, new string[] { "seal" }), // IsNavySeal
        new Rule("civ_capybara_name", new string[] { "chillbara", "chill_bara", "capybara_people" }, new string[] { "civ_capybara" }, new string[] { "capybara" }), // IsCapybara
        new Rule("civ_crystal_name", new string[] { "crystal_golem", "crystal_people" }, new string[] { "civ_crystal" }, new string[] { "crystal_sword", "crystal", "crystalsword" }), // IsCrystal
        new Rule("civ_snake_name", new string[] { "snok", "snake_people", "snake_civilization" }, new string[] { "civ_snake", "civ_snok" }, new string[] { "snake" }), // IsSnake
        new Rule("civ_wolf_name", new string[] { "howleer", "wolf_people", "wolf_civilization" }, new string[] { "civ_wolf", "civ_howleer" }, new string[] { "wolf" }), // IsWolf
        new Rule("civ_liliar_name", new string[] { "liliar", "lulliar", "liliar_people" }, new string[] { "civ_liliar", "civ_lulliar" }, new string[] { "flower_bud" }), // IsLiliar
    };

    internal static string GetTemplateId(ActorAsset asset)
    {
        if (asset == null) return null;
        RouteCache cache = s_routes.GetValue(asset, CreateCache);
        string rawId = asset.id ?? "";
        bool civilized = asset.civ;
        lock (cache)
        {
            if (!cache.Initialized || cache.RawId != rawId || cache.Civilized != civilized)
            {
                cache.RawId = rawId;
                cache.Civilized = civilized;
                cache.TemplateId = ResolveId(rawId, civilized);
                cache.Initialized = true;
            }
            return cache.TemplateId;
        }
    }

    private static RouteCache CreateCache(ActorAsset asset) { return new RouteCache(); }

    internal static string ResolveId(string rawId, bool civilized)
    {
        string id = Normalize(rawId);
        string coreRace = CoreRaceFramework.FromId(id);
        if (coreRace != null) return CoreRaceFramework.GeneratorId(coreRace, "name");

        foreach (Rule rule in s_rules)
            if (rule.Matches(id, civilized)) return rule.TemplateId;

        bool looksCivilized = civilized || id.StartsWith("civ_", StringComparison.Ordinal);
        if (id.Contains("punkcorn") || (looksCivilized && id.Contains("unicorn")))
            return "civ_punkcorn_name";

        string smallId = V105FallbackFramework.SmallCreatureIdFromId(id);
        if (smallId != null) return smallId + "_name";
        if (looksCivilized) return V105FallbackFramework.UnknownGenerator("name");

        if ((id.Contains("fire") && id.Contains("elemental")) || id.Contains("fire_dlemental"))
            return "fire_elemental_name";
        if (V105FallbackFramework.IsCuratedPlainActorId(id)) return id + "_name";
        return V105FallbackFramework.UnknownGenerator("name");
    }

    internal static string Normalize(string value)
    {
        return string.IsNullOrWhiteSpace(value) ? "" :
            value.Trim().ToLowerInvariant().Replace(" ", "_").Replace("-", "_");
    }
}
